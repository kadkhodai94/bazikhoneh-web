# بازی خونه - Flutter WebView

این نسخه فایل HTML اصلی را بدون تغییر UI داخل Flutter WebView اجرا می‌کند.

## Build
```bash
flutter pub get
flutter build apk --release
```
