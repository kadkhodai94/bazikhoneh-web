# بازی خونه WebView Flutter v8

نسخه اصلاح R8 برای Adivery.

تغییرات:
- حفظ UI HTML و صفحات بازی
- Adivery فعال
- اصلاح compileSdk 36
- اصلاح Kotlin
- غیرفعال‌سازی shrink/minify برای رفع خطای Missing classes/R8 مربوط به mbridge
