# BaziKhone WebView Flutter v4 - Adivery

نسخه WebView بازی‌خونه با UI اصلی HTML بدون تغییر در صفحات بازی.

تغییرات v4:
- اضافه‌شدن Adivery App ID و placementها
- بنر تبلیغاتی پایین اپ
- تبلیغ تمام‌صفحه هر ۵ بار ورود به بازی
- تبلیغ ویدئویی جایزه‌ای از منوی اپ
- دکمه خروج از اپ با دیالوگ تأیید
- ۳ صفحه راهنمای سریع
- حذف کامل صفحه انتظار شروع بازی طبق درخواست

Workflow داخل `.github/workflows/build.yml` پروژه Android سالم می‌سازد و APK/AAB خروجی می‌گیرد.


## v5
- Fixed Adivery dependency version: adivery ^4.8.8.
- Kept UI and game HTML unchanged.
