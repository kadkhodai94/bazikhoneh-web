# بازی خونه Flutter WebView v6

اصلاحات این نسخه:

- اصلاح خطای BannerAd و BannerAdSize در Adivery 4.8.8
- جایگزینی بنر با AndroidView سازگار با پکیج ادیوری
- تنظیم compileSdk روی 36 در workflow
- حفظ UI و صفحات HTML بازی
- حفظ تبلیغ تمام‌صفحه هر ۵ ورود به بازی، ویدیویی، دکمه خروج و ۳ صفحه راهنما
