# بازی خونه WebView Flutter v17.1

اصلاح build:
- خطای nullable bool در AdiveryPlugin.isLoaded رفع شد.
- منطق v17 حفظ شد.
- لودینگ اختصاصی، sync سکه و اصلاحات تبلیغات حفظ شدند.

ZIP را در ریشه GitHub بگذار و ZIPهای قبلی را حذف کن.
