import 'dart:convert';
import 'dart:io' show Platform;

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String _adiveryAppId = 'aa714944-d43d-43d4-9d36-1cb3404cefbc';
const String _bannerPlacementId = '2982cc2e-11c7-4051-80cc-6149a623000a';
const String _rewardedPlacementId = '110aae68-ff23-4d1f-85cc-c66bbae6337e';
const String _interstitialPlacementId = '814de6e1-7ca3-4c30-8656-1eb165307232';
const String _gameStartCounterKey = 'game_start_counter_v1';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  _safeInitAdivery();
  runApp(const BaziKhoneWebViewApp());
}

void _safeInitAdivery() {
  if (!Platform.isAndroid) return;
  try {
    AdiveryPlugin.initialize(_adiveryAppId);
    AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
  } catch (_) {
    // Build and app startup should never fail if the ad SDK is not ready.
  }
}

class BaziKhoneWebViewApp extends StatelessWidget {
  const BaziKhoneWebViewApp({super.key});


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GameWebViewScreen(),
    );
  }
}

class GameWebViewScreen extends StatefulWidget {
  const GameWebViewScreen({super.key});

  @override
  State<GameWebViewScreen> createState() => _GameWebViewScreenState();
}

class _GameWebViewScreenState extends State<GameWebViewScreen> with WidgetsBindingObserver {
  late final WebViewController _controller;
  var _loading = true;
  var _showChrome = true;
  bool _hideBottomBanner = false;
  int _pendingRewardAmount = 0;
  String _pendingRewardLabel = 'پاداش تبلیغ ویدئویی';
  bool _adiveryListenerAttached = false;
  late final Widget _adiveryBannerWidget;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _adiveryBannerWidget = Platform.isAndroid
        ? BannerAd(_bannerPlacementId, BannerAdSize.BANNER)
        : const SizedBox.shrink();
    _setupAdiveryRewardListener();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..addJavaScriptChannel(
        'BaziBridge',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'game_start') {
            _handleGameStartAd();
          }
        },
      )
      ..addJavaScriptChannel(
        'BaziNativeAdBridge',
        onMessageReceived: (JavaScriptMessage message) {
          _handleNativeAdSlotMessage(message.message);
        },
      )
      ..addJavaScriptChannel(
        'BaziRewardedAdBridge',
        onMessageReceived: (JavaScriptMessage message) {
          _handleRewardedAdRequest(message.message);
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) {
            if (mounted) setState(() => _loading = true);
          },
          onPageFinished: (_) async {
            await _injectGameStartDetector();
            await _injectNativeAdSlotDetector();
            await _injectRewardedVideoBridge();
            if (mounted) setState(() => _loading = false);
          },
          onNavigationRequest: (NavigationRequest request) {
            final url = request.url.toLowerCase();
            if (url.startsWith('http://') ||
                url.startsWith('https://') ||
                url.startsWith('intent://') ||
                url.startsWith('market://')) {
              // v17: از خروج ناخواسته WebView به Chrome/مارکت جلوگیری می‌شود.
              return NavigationDecision.prevent;
            }
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadFlutterAsset('assets/game.html');
  }

  int _rewardSessionId = 0;
  bool _rewardCallbackReceived = false;
  DateTime? _rewardStartedAt;
  bool _rewardLifecycleFallbackSent = false;


  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    // v16: هیچ جایزه‌ای از روی lifecycle داده نمی‌شود؛ فقط callback واقعی ادیوری معتبر است.
  }

  void _setupAdiveryRewardListener() {
    if (!Platform.isAndroid || _adiveryListenerAttached) return;
    _adiveryListenerAttached = true;
    try {
      AdiveryPlugin.addListener(
        onRewardedClosed: (String placementId, bool isRewarded) async {
          if (_pendingRewardAmount <= 0) return;
          _rewardCallbackReceived = true;
          final started = _rewardStartedAt;
          final elapsedSeconds = started == null
              ? 0
              : DateTime.now().difference(started).inSeconds;
          // v17: جایزه فقط وقتی داده می‌شود که ادیوری rewarded=true بدهد
          // و تبلیغ به‌صورت غیرطبیعی/خیلی سریع بسته نشده باشد.
          final validReward = isRewarded && elapsedSeconds >= 6;
          await _dispatchRewardedResult(validReward);
          if (isRewarded && !validReward) {
            try {
              await _controller.runJavaScript(
                "try{if(window.bhShowToast)window.bhShowToast('تبلیغ کامل پخش نشد؛ سکه‌ای اضافه نشد');}catch(e){}",
              );
            } catch (_) {}
          }
          try {
            AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
          } catch (_) {}
        },
      );
    } catch (_) {}
  }

  Future<void> _dispatchRewardedResult(bool isRewarded) async {
    final amount = _pendingRewardAmount > 0 ? _pendingRewardAmount : 1000;
    final label = _escapeJsString(_pendingRewardLabel);
    final ok = isRewarded ? 'true' : 'false';
    try {
      await _controller.runJavaScript(
        "try{"
        "if(window.__bhForceRewardGrantFromNative){window.__bhForceRewardGrantFromNative($ok,$amount,'$label');}"
        "else if(window.baziKhoneRewardedAdResult){window.baziKhoneRewardedAdResult($ok,$amount,'$label');}"
        "else if($ok && window.bhAddCoins){window.bhAddCoins($amount,'$label');}"
        "else if(!$ok && window.bhShowToast){window.bhShowToast('برای دریافت سکه باید تبلیغ را کامل ببینی');}"
        "if(window.__bhV17SyncCoins){window.__bhV17SyncCoins();}else if(window.__bhV14SyncCoins){window.__bhV14SyncCoins();}"
        "}catch(e){}",
      );
    } catch (_) {}
    _pendingRewardAmount = 0;
    _pendingRewardLabel = 'پاداش تبلیغ ویدئویی';
    _rewardStartedAt = null;
    _rewardLifecycleFallbackSent = false;
  }

  String _escapeJsString(String value) {
    return value
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('\n', ' ')
        .replaceAll('\r', ' ');
  }

  Future<void> _injectGameStartDetector() async {
    const js = r'''
(function(){
  if (window.__baziKhoneAdiveryBridgeInstalled) return;
  window.__baziKhoneAdiveryBridgeInstalled = true;
  document.addEventListener('click', function(event){
    var target = event.target;
    if (!target) return;
    var gameNode = target.closest ? target.closest('[data-game], .game-card, .game-start, [data-start-game]') : null;
    if (gameNode && window.BaziBridge && window.BaziBridge.postMessage) {
      window.BaziBridge.postMessage('game_start');
    }
  }, true);
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }


  Future<void> _injectNativeAdSlotDetector() async {
    const js = r'''
(function(){
  if (window.__baziKhoneBottomBannerControllerV18) return;
  window.__baziKhoneBottomBannerControllerV18 = true;

  function post(message){
    try{
      if (window.BaziNativeAdBridge && window.BaziNativeAdBridge.postMessage) {
        window.BaziNativeAdBridge.postMessage(JSON.stringify(message));
      }
    }catch(e){}
  }

  function hasBlockingOverlay(){
    try{
      var selectors = [
        '.feature-modal.show',
        '.modal.show',
        '.game-confirm-popup.show',
        '.bhp-ticket-modal.show',
        '#videoRewardModal.show',
        '#coinSuccessModal.show',
        '[aria-modal="true"]'
      ];
      for (var i=0;i<selectors.length;i++){
        var nodes = document.querySelectorAll(selectors[i]);
        for (var j=0;j<nodes.length;j++){
          var node = nodes[j];
          var style = window.getComputedStyle(node);
          var rect = node.getBoundingClientRect();
          if (style.display !== 'none' &&
              style.visibility !== 'hidden' &&
              style.opacity !== '0' &&
              rect.width > 80 &&
              rect.height > 80) {
            return true;
          }
        }
      }
    }catch(e){}
    return false;
  }

  function report(){
    if (hasBlockingOverlay()) {
      post({type:'banner_hide'});
    } else {
      post({type:'banner_show'});
    }
  }

  window.addEventListener('scroll', report, true);
  window.addEventListener('resize', report, true);
  document.addEventListener('click', function(){ setTimeout(report, 80); setTimeout(report, 350); }, true);
  try{
    var observer = new MutationObserver(report);
    observer.observe(document.documentElement, {subtree:true, attributes:true, attributeFilter:['class','style','aria-hidden']});
  }catch(e){}
  setTimeout(report, 250);
  setTimeout(report, 900);
  setInterval(report, 1000);
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }

  Future<void> _injectRewardedVideoBridge() async {
    const js = r'''
(function(){
  if (window.__baziKhoneRewardedResultInstalled) return;
  window.__baziKhoneRewardedResultInstalled = true;
  window.baziKhoneRewardedAdResult = window.baziKhoneRewardedAdResult || function(isRewarded, amount, label){
    try{
      var ok = isRewarded === true || isRewarded === 'true' || isRewarded === 1 || isRewarded === '1';
      var finalAmount = Number(amount || 1000);
      var finalLabel = label || 'پاداش تبلیغ ویدئویی';
      var modal = document.getElementById('videoRewardModal');
      if (modal) {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
      }
      if (ok) {
        if (window.bhAddCoins) window.bhAddCoins(finalAmount, finalLabel);
        else if (window.bhShowToast) window.bhShowToast(finalAmount + ' سکه اضافه شد');
      } else {
        if (window.bhShowToast) window.bhShowToast('برای دریافت سکه باید تبلیغ را کامل ببینی');
      }
    }catch(e){}
  };
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }

  Future<void> _handleRewardedAdRequest(String rawMessage) async {
    var amount = 1000;
    var label = 'پاداش تبلیغ ویدئویی';
    try {
      final decoded = jsonDecode(rawMessage);
      if (decoded is Map<String, dynamic>) {
        final rawAmount = decoded['amount'];
        if (rawAmount is num && rawAmount > 0) amount = rawAmount.toInt();
        final rawLabel = decoded['label'];
        if (rawLabel is String && rawLabel.trim().isNotEmpty) label = rawLabel.trim();
      }
    } catch (_) {}
    await _showRewardedAdFromGame(amount: amount, label: label);
  }

  Future<void> _showRewardedAdFromGame({required int amount, required String label}) async {
    _pendingRewardAmount = amount;
    _pendingRewardLabel = label;
    _rewardStartedAt = DateTime.now();
    _rewardLifecycleFallbackSent = false;
    final sessionId = ++_rewardSessionId;
    _rewardCallbackReceived = false;

    if (!Platform.isAndroid) {
      try {
        await _controller.runJavaScript(
          "try{if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(false, $amount, '${_escapeJsString(label)}'); if(window.bhShowToast)window.bhShowToast('تبلیغ فقط در نسخه اندروید فعال است');}catch(e){}",
        );
      } catch (_) {}
      _pendingRewardAmount = 0;
      return;
    }

    try {
      bool isReady = false;
      try {
        isReady = (await AdiveryPlugin.isLoaded(_rewardedPlacementId)) == true;
      } catch (_) {
        isReady = false;
      }

      if (!isReady) {
        try {
          AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
        } catch (_) {}
        await _controller.runJavaScript(
          "try{if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(false, $amount, '${_escapeJsString(label)}'); if(window.bhShowToast)window.bhShowToast('تبلیغ فعلاً آماده نیست، چند لحظه بعد دوباره تلاش کن');}catch(e){}",
        );
        _pendingRewardAmount = 0;
        return;
      }

      await _controller.runJavaScript(
        "try{if(window.bhShowToast)window.bhShowToast('در حال باز کردن تبلیغ ویدئویی...');}catch(e){}",
      );
      AdiveryPlugin.show(_rewardedPlacementId);
      try {
        AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
      } catch (_) {}

      // v16: fallback جایزه حذف شد. فقط onRewardedClosed با isRewarded=true سکه می‌دهد.
      Future<void>.delayed(const Duration(seconds: 35), () async {
        if (!mounted) return;
        if (_pendingRewardAmount > 0 && _rewardSessionId == sessionId && !_rewardCallbackReceived) {
          await _controller.runJavaScript(
            "try{if(window.bhShowToast)window.bhShowToast('وضعیت تبلیغ تأیید نشد؛ سکه‌ای اضافه نشد'); if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(false, $amount, '${_escapeJsString(label)}');}catch(e){}",
          );
          _pendingRewardAmount = 0;
        }
      });
    } catch (_) {
      try {
        AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
      } catch (_) {}
      try {
        await _controller.runJavaScript(
          "try{if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(false, $amount, '${_escapeJsString(label)}'); if(window.bhShowToast)window.bhShowToast('تبلیغ ویدئویی اجرا نشد');}catch(e){}",
        );
      } catch (_) {}
      _pendingRewardAmount = 0;
    }
  }

  void _handleNativeAdSlotMessage(String rawMessage) {
    if (!Platform.isAndroid) return;

    try {
      final decoded = jsonDecode(rawMessage);
      if (decoded is! Map<String, dynamic>) return;
      final type = decoded['type'];

      if (type == 'banner_hide') {
        if (!_hideBottomBanner && mounted) {
          setState(() => _hideBottomBanner = true);
        }
        return;
      }

      if (type == 'banner_show' || type == 'banner_rect' || type == 'banner_keep') {
        if (_hideBottomBanner && mounted) {
          setState(() => _hideBottomBanner = false);
        }
        return;
      }
    } catch (_) {}
  }

  Future<void> _handleGameStartAd() async {
    final prefs = await SharedPreferences.getInstance();
    final nextCount = (prefs.getInt(_gameStartCounterKey) ?? 0) + 1;
    await prefs.setInt(_gameStartCounterKey, nextCount);

    if (nextCount % 5 != 0) return;
    _showInterstitialAd();
  }

  void _showInterstitialAd() {
    if (!Platform.isAndroid) return;
    try {
      AdiveryPlugin.show(_interstitialPlacementId);
      AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    } catch (_) {}
  }

  Future<bool> _onBackPressed() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  Future<void> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('خروج از بازی'),
        content: const Text('می‌خواهی از برنامه خارج شوی؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('نه'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('خروج'),
          ),
        ],
      ),
    );

    if (shouldExit == true && mounted) {
      Navigator.of(context).maybePop();
    }
  }

  void _openHelp() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _HelpPagesSheet(),
    );
  }

  void _openMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            margin: const EdgeInsets.all(14),
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
            decoration: BoxDecoration(
              color: const Color(0xFF241B52),
              borderRadius: BorderRadius.circular(26),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 24,
                  offset: Offset(0, 10),
                  color: Color(0x55000000),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'بازی‌خونه',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _MenuActionButton(
                    icon: Icons.help_rounded,
                    title: 'راهنمای بازی',
                    subtitle: '۳ صفحه راهنمای سریع',
                    onTap: () {
                      Navigator.of(context).pop();
                      _openHelp();
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.play_circle_fill_rounded,
                    title: 'تبلیغ ویدیویی',
                    subtitle: 'آماده برای جایزه و دریافت امتیاز',
                    onTap: () {
                      Navigator.of(context).pop();
                      _showRewardedAdFromGame(amount: 1000, label: 'پاداش تبلیغ ویدئویی');
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.exit_to_app_rounded,
                    title: 'خروج از اپ',
                    subtitle: 'بستن برنامه با تأیید کاربر',
                    onTap: () {
                      Navigator.of(context).pop();
                      _confirmExit();
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        final shouldPop = await _onBackPressed();
        if (shouldPop && mounted) {
          _confirmExit();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Stack(
            children: [
              Positioned.fill(
                child: Padding(
                  padding: EdgeInsets.only(
                    bottom: _shouldShowBottomBanner(context) ? _bottomBannerReservedHeight(context) : 0,
                  ),
                  child: WebViewWidget(controller: _controller),
                ),
              ),
              if (_shouldShowBottomBanner(context))
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 0,
                  child: _BottomAdiveryBanner(
                    child: _adiveryBannerWidget,
                  ),
                ),
              if (_loading)
                const Positioned.fill(
                  child: _GameLoadingOverlay(),
                ),
            ],
          ),
        ),
      ),
    );
  }
}


class _GameLoadingOverlay extends StatefulWidget {
  const _GameLoadingOverlay();

  @override
  State<_GameLoadingOverlay> createState() => _GameLoadingOverlayState();
}

class _GameLoadingOverlayState extends State<_GameLoadingOverlay>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1700),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [
              Color(0xFFFFF8EC),
              Color(0xFFF9E7C9),
              Color(0xFFF6DFC0),
            ],
          ),
        ),
        child: Stack(
          children: [
            Positioned(
              top: -40,
              right: -35,
              child: _GlowBubble(size: 180, colors: const [Color(0x55F19A31), Color(0x22E72B91)]),
            ),
            Positioned(
              bottom: -30,
              left: -20,
              child: _GlowBubble(size: 150, colors: const [Color(0x44A45CFF), Color(0x22FFFFFF)]),
            ),
            Center(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    SizedBox(
                      width: 160,
                      height: 160,
                      child: Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: 152,
                            height: 152,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              gradient: const LinearGradient(
                                begin: Alignment.topLeft,
                                end: Alignment.bottomRight,
                                colors: [Color(0xFFFFC254), Color(0xFFF0952C), Color(0xFFE33A91)],
                              ),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x33E95F37),
                                  blurRadius: 30,
                                  spreadRadius: 2,
                                  offset: Offset(0, 14),
                                )
                              ],
                              border: Border.all(color: const Color(0xFFFFE5A6), width: 3),
                            ),
                          ),
                          RotationTransition(
                            turns: _controller,
                            child: Container(
                              width: 124,
                              height: 124,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: Colors.white.withOpacity(.18),
                                border: Border.all(color: Colors.white.withOpacity(.55), width: 2),
                              ),
                            ),
                          ),
                          Container(
                            width: 108,
                            height: 108,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(34),
                              gradient: const LinearGradient(
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                colors: [Color(0xFF5D1ED8), Color(0xFF9426E1)],
                              ),
                              border: Border.all(color: const Color(0xFFFFD98F), width: 3),
                              boxShadow: const [
                                BoxShadow(
                                  color: Color(0x22000000),
                                  blurRadius: 20,
                                  offset: Offset(0, 8),
                                ),
                              ],
                            ),
                            child: const Center(
                              child: Text(
                                'بازی',
                                style: TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w900,
                                  fontSize: 28,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 26),
                    const Text(
                      'بازی خونه',
                      style: TextStyle(
                        fontSize: 31,
                        fontWeight: FontWeight.w900,
                        color: Color(0xFF40135A),
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'در حال آماده‌سازی بازی‌ها، مسابقه‌ها و جوایز...',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: Color(0xFF7A5A69),
                        height: 1.8,
                      ),
                    ),
                    const SizedBox(height: 22),
                    Container(
                      width: 230,
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.65),
                        borderRadius: BorderRadius.circular(26),
                        border: Border.all(color: const Color(0xFFFFE1B2)),
                        boxShadow: const [
                          BoxShadow(
                            color: Color(0x12A5581E),
                            blurRadius: 16,
                            offset: Offset(0, 8),
                          )
                        ],
                      ),
                      child: AnimatedBuilder(
                        animation: _controller,
                        builder: (context, _) {
                          return Stack(
                            children: [
                              Container(height: 16),
                              FractionallySizedBox(
                                widthFactor: 0.28 + (_controller.value * 0.58),
                                child: Container(
                                  height: 16,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(18),
                                    gradient: const LinearGradient(
                                      colors: [Color(0xFFFF8B32), Color(0xFFE72B91), Color(0xFF7A23DB)],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          );
                        },
                      ),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: List.generate(3, (index) {
                        return AnimatedBuilder(
                          animation: _controller,
                          builder: (context, _) {
                            final phase = (_controller.value * 3 - index).abs();
                            final scale = 0.72 + (1 - phase.clamp(0, 1)) * 0.48;
                            return Container(
                              width: 14,
                              height: 14,
                              margin: const EdgeInsets.symmetric(horizontal: 4),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: index == 0
                                    ? const Color(0xFFFFA43D)
                                    : index == 1
                                        ? const Color(0xFFE84898)
                                        : const Color(0xFF7B30E5),
                              ),
                              transform: Matrix4.identity()..scale(scale, scale),
                            );
                          },
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _GlowBubble extends StatelessWidget {
  const _GlowBubble({required this.size, required this.colors});

  final double size;
  final List<Color> colors;


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: RadialGradient(colors: colors),
      ),
    );
  }
}

class _BottomAdiveryBanner extends StatelessWidget {
  const _BottomAdiveryBanner({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (!Platform.isAndroid) {
      return const SizedBox.shrink();
    }

    return SafeArea(
      top: false,
      child: Container(
        height: 58,
        width: double.infinity,
        padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
        decoration: BoxDecoration(
          color: const Color(0xFFFFF5E5).withOpacity(.96),
          border: const Border(
            top: BorderSide(color: Color(0x22A55A12), width: 1),
          ),
          boxShadow: const [
            BoxShadow(
              color: Color(0x22000000),
              blurRadius: 16,
              offset: Offset(0, -6),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(12),
          child: child,
        ),
      ),
    );
  }
}

class _FloatingMenuButton extends StatelessWidget {
  const _FloatingMenuButton({required this.onTap});

  final VoidCallback onTap;


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xDD241B52),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: const SizedBox(
          width: 44,
          height: 44,
          child: Icon(Icons.menu_rounded, color: Colors.white),
        ),
      ),
    );
  }
}

class _MenuActionButton extends StatelessWidget {
  const _MenuActionButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.10),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD166),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: const Color(0xFF241B52)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.74),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }
}

class _HelpPagesSheet extends StatefulWidget {
  const _HelpPagesSheet();

  @override
  State<_HelpPagesSheet> createState() => _HelpPagesSheetState();
}

class _HelpPagesSheetState extends State<_HelpPagesSheet> {
  final PageController _pageController = PageController();
  int _page = 0;

  static const _pages = [
    _HelpPageData(
      icon: Icons.sports_esports_rounded,
      title: 'شروع بازی',
      text: 'از صفحه اصلی یکی از بازی‌ها را انتخاب کن، مقدار سکه ورود را ببین و بازی را شروع کن. مسیر و ظاهر بازی‌ها همان نسخه اصلی حفظ شده است.',
    ),
    _HelpPageData(
      icon: Icons.monetization_on_rounded,
      title: 'سکه و امتیاز',
      text: 'با بردن بازی‌ها سکه و امتیاز می‌گیری. رتبه، رکورد و جایزه‌ها داخل خود بازی مدیریت می‌شوند و صفحه‌های بازی بدون تغییر اجرا می‌شوند.',
    ),
    _HelpPageData(
      icon: Icons.touch_app_rounded,
      title: 'دکمه‌ها و تبلیغات',
      text: 'از دکمه منو می‌توانی راهنما، تبلیغ ویدیویی و خروج از اپ را باز کنی. تبلیغ تمام‌صفحه هر ۵ بار ورود به بازی فقط یک‌بار نمایش داده می‌شود.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }


  bool _shouldShowBottomBanner(BuildContext context) {
    return Platform.isAndroid && _showChrome && !_loading && !_hideBottomBanner;
  }

  double _bottomBannerReservedHeight(BuildContext context) {
    return 58.0 + MediaQuery.paddingOf(context).bottom;
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DraggableScrollableSheet(
        initialChildSize: 0.78,
        minChildSize: 0.45,
        maxChildSize: 0.92,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Color(0xFFF8F5FF),
              borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
            ),
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(
                  width: 48,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFB9A7E8),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'راهنمای سریع بازی‌خونه',
                  style: TextStyle(
                    color: Color(0xFF241B52),
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: _pages.length,
                    onPageChanged: (value) => setState(() => _page = value),
                    itemBuilder: (context, index) {
                      final item = _pages[index];
                      return Padding(
                        padding: const EdgeInsets.all(20),
                        child: Container(
                          padding: const EdgeInsets.all(22),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 24,
                                offset: Offset(0, 10),
                                color: Color(0x16000000),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFF7C3AED), Color(0xFFFFD166)],
                                  ),
                                  borderRadius: BorderRadius.circular(32),
                                ),
                                child: Icon(item.icon, size: 50, color: Colors.white),
                              ),
                              const SizedBox(height: 24),
                              Text(
                                item.title,
                                style: const TextStyle(
                                  color: Color(0xFF241B52),
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                item.text,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Color(0xFF4C426E),
                                  fontSize: 15,
                                  height: 1.8,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _page == index ? 28 : 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: _page == index ? const Color(0xFF7C3AED) : const Color(0xFFD8CCF7),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      backgroundColor: const Color(0xFF7C3AED),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    onPressed: () {
                      if (_page < _pages.length - 1) {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 260),
                          curve: Curves.easeOut,
                        );
                      } else {
                        Navigator.of(context).pop();
                      }
                    },
                    child: Text(_page < _pages.length - 1 ? 'بعدی' : 'متوجه شدم'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HelpPageData {
  const _HelpPageData({
    required this.icon,
    required this.title,
    required this.text,
  });

  final IconData icon;
  final String title;
  final String text;
}
