# بازی خونه WebView Flutter v7

Fixes:
- Adivery package remains 4.8.8.
- Banner uses official `adivery_ads.dart` BannerAd widget.
- Build workflow patches compileSdk/targetSdk to 36.
- Build workflow patches Kotlin Gradle plugin to 2.1.10 to match Adivery dependencies.
- UI and HTML game pages are unchanged.
