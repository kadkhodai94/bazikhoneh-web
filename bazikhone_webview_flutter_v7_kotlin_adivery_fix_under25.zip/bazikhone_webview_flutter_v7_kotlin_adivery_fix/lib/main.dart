import 'dart:io' show Platform;

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String _adiveryAppId = 'aa714944-d43d-43d4-9d36-1cb3404cefbc';
const String _bannerPlacementId = '2982cc2e-11c7-4051-80cc-6149a623000a';
const String _rewardedPlacementId = '5d4c9b82-8d02-4978-859a-04368264e1cb';
const String _interstitialPlacementId = '814de6e1-7ca3-4c30-8656-1eb165307232';
const String _gameStartCounterKey = 'game_start_counter_v1';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  _safeInitAdivery();
  runApp(const BaziKhoneWebViewApp());
}

void _safeInitAdivery() {
  if (!Platform.isAndroid) return;
  try {
    AdiveryPlugin.initialize(_adiveryAppId);
    AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
  } catch (_) {
    // Build and app startup should never fail if the ad SDK is not ready.
  }
}

class BaziKhoneWebViewApp extends StatelessWidget {
  const BaziKhoneWebViewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GameWebViewScreen(),
    );
  }
}

class GameWebViewScreen extends StatefulWidget {
  const GameWebViewScreen({super.key});

  @override
  State<GameWebViewScreen> createState() => _GameWebViewScreenState();
}

class _GameWebViewScreenState extends State<GameWebViewScreen> {
  late final WebViewController _controller;
  var _loading = true;
  var _showChrome = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..addJavaScriptChannel(
        'BaziBridge',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'game_start') {
            _handleGameStartAd();
          }
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) async {
            await _injectGameStartDetector();
            if (mounted) setState(() => _loading = false);
          },
        ),
      )
      ..loadFlutterAsset('assets/game.html');
  }

  Future<void> _injectGameStartDetector() async {
    const js = r'''
(function(){
  if (window.__baziKhoneAdiveryBridgeInstalled) return;
  window.__baziKhoneAdiveryBridgeInstalled = true;
  document.addEventListener('click', function(event){
    var target = event.target;
    if (!target) return;
    var gameNode = target.closest ? target.closest('[data-game], .game-card, .game-start, [data-start-game]') : null;
    if (gameNode && window.BaziBridge && window.BaziBridge.postMessage) {
      window.BaziBridge.postMessage('game_start');
    }
  }, true);
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }

  Future<void> _handleGameStartAd() async {
    final prefs = await SharedPreferences.getInstance();
    final nextCount = (prefs.getInt(_gameStartCounterKey) ?? 0) + 1;
    await prefs.setInt(_gameStartCounterKey, nextCount);

    if (nextCount % 5 != 0) return;
    _showInterstitialAd();
  }

  void _showInterstitialAd() {
    if (!Platform.isAndroid) return;
    try {
      AdiveryPlugin.show(_interstitialPlacementId);
      AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    } catch (_) {}
  }

  void _showRewardedAd() {
    if (!Platform.isAndroid) return;
    try {
      AdiveryPlugin.show(_rewardedPlacementId);
      AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
    } catch (_) {}
  }

  Future<bool> _onBackPressed() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  Future<void> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('خروج از بازی'),
        content: const Text('می‌خواهی از برنامه خارج شوی؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('نه'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('خروج'),
          ),
        ],
      ),
    );

    if (shouldExit == true && mounted) {
      Navigator.of(context).maybePop();
    }
  }

  void _openHelp() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _HelpPagesSheet(),
    );
  }

  void _openMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            margin: const EdgeInsets.all(14),
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
            decoration: BoxDecoration(
              color: const Color(0xFF241B52),
              borderRadius: BorderRadius.circular(26),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 24,
                  offset: Offset(0, 10),
                  color: Color(0x55000000),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'بازی‌خونه',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _MenuActionButton(
                    icon: Icons.help_rounded,
                    title: 'راهنمای بازی',
                    subtitle: '۳ صفحه راهنمای سریع',
                    onTap: () {
                      Navigator.of(context).pop();
                      _openHelp();
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.play_circle_fill_rounded,
                    title: 'تبلیغ ویدیویی',
                    subtitle: 'آماده برای جایزه و دریافت امتیاز',
                    onTap: () {
                      Navigator.of(context).pop();
                      _showRewardedAd();
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.exit_to_app_rounded,
                    title: 'خروج از اپ',
                    subtitle: 'بستن برنامه با تأیید کاربر',
                    onTap: () {
                      Navigator.of(context).pop();
                      _confirmExit();
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        final shouldPop = await _onBackPressed();
        if (shouldPop && mounted) {
          _confirmExit();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Stack(
            children: [
              Column(
                children: [
                  Expanded(
                    child: WebViewWidget(controller: _controller),
                  ),
                  if (_showChrome) const _AdiveryBannerArea(),
                ],
              ),
              PositionedDirectional(
                top: MediaQuery.of(context).padding.top + 8,
                start: 10,
                child: _FloatingMenuButton(onTap: _openMenu),
              ),
              PositionedDirectional(
                top: MediaQuery.of(context).padding.top + 8,
                end: 10,
                child: _ChromeToggleButton(
                  visible: _showChrome,
                  onTap: () => setState(() => _showChrome = !_showChrome),
                ),
              ),
              if (_loading)
                Container(
                  color: Colors.white,
                  child: const Center(child: CircularProgressIndicator()),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AdiveryBannerArea extends StatelessWidget {
  const _AdiveryBannerArea();

  @override
  Widget build(BuildContext context) {
    if (!Platform.isAndroid) {
      return const SizedBox.shrink();
    }

    return Container(
      height: 58,
      width: double.infinity,
      alignment: Alignment.center,
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF241B52), Color(0xFF7C3AED)],
        ),
      ),
      child: SizedBox(
        height: 50,
        child: BannerAd(_bannerPlacementId, BannerAdSize.BANNER),
      ),
    );
  }
}

class _FloatingMenuButton extends StatelessWidget {
  const _FloatingMenuButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xDD241B52),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: const SizedBox(
          width: 44,
          height: 44,
          child: Icon(Icons.menu_rounded, color: Colors.white),
        ),
      ),
    );
  }
}

class _ChromeToggleButton extends StatelessWidget {
  const _ChromeToggleButton({required this.visible, required this.onTap});

  final bool visible;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xDD241B52),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: SizedBox(
          width: 44,
          height: 44,
          child: Icon(
            visible ? Icons.fullscreen_rounded : Icons.fullscreen_exit_rounded,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}

class _MenuActionButton extends StatelessWidget {
  const _MenuActionButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.10),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD166),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: const Color(0xFF241B52)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.74),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }
}

class _HelpPagesSheet extends StatefulWidget {
  const _HelpPagesSheet();

  @override
  State<_HelpPagesSheet> createState() => _HelpPagesSheetState();
}

class _HelpPagesSheetState extends State<_HelpPagesSheet> {
  final PageController _pageController = PageController();
  int _page = 0;

  static const _pages = [
    _HelpPageData(
      icon: Icons.sports_esports_rounded,
      title: 'شروع بازی',
      text: 'از صفحه اصلی یکی از بازی‌ها را انتخاب کن، مقدار سکه ورود را ببین و بازی را شروع کن. مسیر و ظاهر بازی‌ها همان نسخه اصلی حفظ شده است.',
    ),
    _HelpPageData(
      icon: Icons.monetization_on_rounded,
      title: 'سکه و امتیاز',
      text: 'با بردن بازی‌ها سکه و امتیاز می‌گیری. رتبه، رکورد و جایزه‌ها داخل خود بازی مدیریت می‌شوند و صفحه‌های بازی بدون تغییر اجرا می‌شوند.',
    ),
    _HelpPageData(
      icon: Icons.touch_app_rounded,
      title: 'دکمه‌ها و تبلیغات',
      text: 'از دکمه منو می‌توانی راهنما، تبلیغ ویدیویی و خروج از اپ را باز کنی. تبلیغ تمام‌صفحه هر ۵ بار ورود به بازی فقط یک‌بار نمایش داده می‌شود.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DraggableScrollableSheet(
        initialChildSize: 0.78,
        minChildSize: 0.45,
        maxChildSize: 0.92,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Color(0xFFF8F5FF),
              borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
            ),
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(
                  width: 48,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFB9A7E8),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'راهنمای سریع بازی‌خونه',
                  style: TextStyle(
                    color: Color(0xFF241B52),
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: _pages.length,
                    onPageChanged: (value) => setState(() => _page = value),
                    itemBuilder: (context, index) {
                      final item = _pages[index];
                      return Padding(
                        padding: const EdgeInsets.all(20),
                        child: Container(
                          padding: const EdgeInsets.all(22),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 24,
                                offset: Offset(0, 10),
                                color: Color(0x16000000),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFF7C3AED), Color(0xFFFFD166)],
                                  ),
                                  borderRadius: BorderRadius.circular(32),
                                ),
                                child: Icon(item.icon, size: 50, color: Colors.white),
                              ),
                              const SizedBox(height: 24),
                              Text(
                                item.title,
                                style: const TextStyle(
                                  color: Color(0xFF241B52),
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                item.text,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Color(0xFF4C426E),
                                  fontSize: 15,
                                  height: 1.8,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _page == index ? 28 : 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: _page == index ? const Color(0xFF7C3AED) : const Color(0xFFD8CCF7),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      backgroundColor: const Color(0xFF7C3AED),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    onPressed: () {
                      if (_page < _pages.length - 1) {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 260),
                          curve: Curves.easeOut,
                        );
                      } else {
                        Navigator.of(context).pop();
                      }
                    },
                    child: Text(_page < _pages.length - 1 ? 'بعدی' : 'متوجه شدم'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HelpPageData {
  const _HelpPageData({
    required this.icon,
    required this.title,
    required this.text,
  });

  final IconData icon;
  final String title;
  final String text;
}
