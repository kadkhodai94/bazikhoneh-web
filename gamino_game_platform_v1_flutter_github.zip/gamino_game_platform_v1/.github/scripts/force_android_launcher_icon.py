from pathlib import Path
from PIL import Image
import re

root = Path.cwd()
icon_path = root / 'assets' / 'app_icon' / 'app_icon.png'
if not icon_path.exists():
    print('No custom app icon found; skipping icon injection.')
    raise SystemExit(0)

img = Image.open(icon_path).convert('RGBA')
android = root / 'android' / 'app' / 'src' / 'main'
res = android / 'res'
legacy_sizes = {
    'mipmap-mdpi': 48,
    'mipmap-hdpi': 72,
    'mipmap-xhdpi': 96,
    'mipmap-xxhdpi': 144,
    'mipmap-xxxhdpi': 192,
}
for folder, size in legacy_sizes.items():
    out = res / folder
    out.mkdir(parents=True, exist_ok=True)
    resized = img.resize((size, size), Image.LANCZOS)
    resized.save(out / 'ic_launcher.png')
    resized.save(out / 'ic_launcher_round.png')

# Adaptive icon foreground/background for Android 8+
fg_dir = res / 'mipmap-xxxhdpi'
fg_dir.mkdir(parents=True, exist_ok=True)
img.resize((432, 432), Image.LANCZOS).save(fg_dir / 'ic_launcher_foreground.png')

anydpi = res / 'mipmap-anydpi-v26'
anydpi.mkdir(parents=True, exist_ok=True)
(anydpi / 'ic_launcher.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n''', encoding='utf-8')
(anydpi / 'ic_launcher_round.xml').write_text('''<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n    <background android:drawable="@color/ic_launcher_background"/>\n    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n''', encoding='utf-8')
values = res / 'values'
values.mkdir(parents=True, exist_ok=True)
colors = values / 'colors.xml'
content = colors.read_text(encoding='utf-8') if colors.exists() else '<resources>\n</resources>\n'
if 'ic_launcher_background' not in content:
    content = content.replace('</resources>', '    <color name="ic_launcher_background">#090C18</color>\n</resources>')
colors.write_text(content, encoding='utf-8')

manifest = android / 'AndroidManifest.xml'
if manifest.exists():
    text = manifest.read_text(encoding='utf-8')
    text = re.sub(r'android:icon="[^"]*"', 'android:icon="@mipmap/ic_launcher"', text)
    text = re.sub(r'android:roundIcon="[^"]*"', 'android:roundIcon="@mipmap/ic_launcher_round"', text)
    if 'android:roundIcon=' not in text:
        text = text.replace('android:icon="@mipmap/ic_launcher"', 'android:icon="@mipmap/ic_launcher"\n        android:roundIcon="@mipmap/ic_launcher_round"')
    manifest.write_text(text, encoding='utf-8')
print('Custom launcher icon injected successfully.')
