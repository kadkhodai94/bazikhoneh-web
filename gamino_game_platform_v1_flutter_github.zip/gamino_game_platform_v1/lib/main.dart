import 'dart:math';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = AppStore();
  await store.load();
  runApp(GameScope(store: store, child: const GaminoApp()));
}

class AppStore extends ChangeNotifier {
  int coins = 850;
  int wins = 0;
  int losses = 0;
  int gamesPlayed = 0;
  int best2048 = 0;
  int avatar = 0;
  int rewardedToday = 0;
  final Set<String> ownedItems = <String>{'avatar_basic'};

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    coins = prefs.getInt('coins') ?? 850;
    wins = prefs.getInt('wins') ?? 0;
    losses = prefs.getInt('losses') ?? 0;
    gamesPlayed = prefs.getInt('gamesPlayed') ?? 0;
    best2048 = prefs.getInt('best2048') ?? 0;
    avatar = prefs.getInt('avatar') ?? 0;
    rewardedToday = prefs.getInt('rewardedToday') ?? 0;
    ownedItems
      ..clear()
      ..addAll((prefs.getStringList('ownedItems') ?? <String>['avatar_basic']));
  }

  Future<void> _save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('coins', coins);
    await prefs.setInt('wins', wins);
    await prefs.setInt('losses', losses);
    await prefs.setInt('gamesPlayed', gamesPlayed);
    await prefs.setInt('best2048', best2048);
    await prefs.setInt('avatar', avatar);
    await prefs.setInt('rewardedToday', rewardedToday);
    await prefs.setStringList('ownedItems', ownedItems.toList());
  }

  void addCoins(int value, {String reason = ''}) {
    coins += value;
    _save();
    notifyListeners();
  }

  bool spendCoins(int value) {
    if (coins < value) return false;
    coins -= value;
    _save();
    notifyListeners();
    return true;
  }

  void recordWin({int reward = 35}) {
    wins++;
    gamesPlayed++;
    coins += reward;
    _save();
    notifyListeners();
  }

  void recordLoss() {
    losses++;
    gamesPlayed++;
    _save();
    notifyListeners();
  }

  void updateBest2048(int score) {
    if (score > best2048) {
      best2048 = score;
      coins += 50;
      _save();
      notifyListeners();
    }
  }

  bool buyItem(String id, int price) {
    if (ownedItems.contains(id)) return true;
    if (!spendCoins(price)) return false;
    ownedItems.add(id);
    _save();
    notifyListeners();
    return true;
  }
}

class GameScope extends InheritedNotifier<AppStore> {
  const GameScope({super.key, required AppStore store, required super.child})
      : super(notifier: store);

  static AppStore of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<GameScope>();
    assert(scope != null, 'GameScope not found');
    return scope!.notifier!;
  }
}

class GaminoApp extends StatelessWidget {
  const GaminoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'گیمینو',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        fontFamily: 'Roboto',
        scaffoldBackgroundColor: const Color(0xFF090C18),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF7C4DFF),
          brightness: Brightness.dark,
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: const SplashPage(),
    );
  }
}

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1300), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => const MainShell()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
            colors: [Color(0xFF21104B), Color(0xFF07101F), Color(0xFF111827)],
          ),
        ),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 118,
                height: 118,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [Color(0xFFFFD166), Color(0xFFFF7A00)],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFFFFD166).withOpacity(.35),
                      blurRadius: 40,
                      spreadRadius: 5,
                    ),
                  ],
                ),
                child: const Icon(Icons.sports_esports_rounded, size: 62, color: Color(0xFF111827)),
              ),
              const SizedBox(height: 24),
              const Text('گیمینو', style: TextStyle(fontSize: 38, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('به دنیای رقابت خوش اومدی', style: TextStyle(color: Colors.white70)),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(onOpenGames: () => setState(() => index = 1), onOpenShop: () => setState(() => index = 3)),
      const GamesPage(),
      const LeaderboardPage(),
      const ShopPage(),
      const ProfilePage(),
    ];
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: PremiumBackground()),
          SafeArea(child: pages[index]),
        ],
      ),
      bottomNavigationBar: Container(
        margin: const EdgeInsets.fromLTRB(14, 0, 14, 12),
        padding: const EdgeInsets.all(8),
        decoration: BoxDecoration(
          color: const Color(0xFF111827).withOpacity(.92),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: Colors.white.withOpacity(.08)),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(.35), blurRadius: 25, offset: const Offset(0, 10))],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            NavPill(icon: Icons.home_rounded, label: 'خانه', selected: index == 0, onTap: () => setState(() => index = 0)),
            NavPill(icon: Icons.grid_view_rounded, label: 'بازی‌ها', selected: index == 1, onTap: () => setState(() => index = 1)),
            NavPill(icon: Icons.emoji_events_rounded, label: 'رتبه', selected: index == 2, onTap: () => setState(() => index = 2)),
            NavPill(icon: Icons.store_rounded, label: 'فروشگاه', selected: index == 3, onTap: () => setState(() => index = 3)),
            NavPill(icon: Icons.person_rounded, label: 'پروفایل', selected: index == 4, onTap: () => setState(() => index = 4)),
          ],
        ),
      ),
    );
  }
}

class PremiumBackground extends StatelessWidget {
  const PremiumBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
          colors: [Color(0xFF120A2D), Color(0xFF07101F), Color(0xFF111827)],
        ),
      ),
      child: Stack(
        children: [
          Positioned(top: -70, right: -60, child: GlowBall(color: Color(0xFF8B5CF6), size: 210)),
          Positioned(bottom: 90, left: -80, child: GlowBall(color: Color(0xFF06B6D4), size: 220)),
          Positioned(top: 220, left: 60, child: GlowBall(color: Color(0xFFFFD166), size: 90)),
        ],
      ),
    );
  }
}

class GlowBall extends StatelessWidget {
  final Color color;
  final double size;
  const GlowBall({super.key, required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: color.withOpacity(.12),
        boxShadow: [BoxShadow(color: color.withOpacity(.24), blurRadius: 70, spreadRadius: 20)],
      ),
    );
  }
}

class NavPill extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;
  const NavPill({super.key, required this.icon, required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: EdgeInsets.symmetric(horizontal: selected ? 12 : 8, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: selected ? const LinearGradient(colors: [Color(0xFF7C4DFF), Color(0xFF00D4FF)]) : null,
        ),
        child: Row(
          children: [
            Icon(icon, size: 22, color: selected ? Colors.white : Colors.white60),
            if (selected) ...[
              const SizedBox(width: 6),
              Text(label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w800)),
            ],
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  final VoidCallback onOpenGames;
  final VoidCallback onOpenShop;
  const HomePage({super.key, required this.onOpenGames, required this.onOpenShop});

  @override
  Widget build(BuildContext context) {
    final store = GameScope.of(context);
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
        children: [
          Row(
            children: [
              const CircleAvatar(
                radius: 28,
                backgroundColor: Color(0xFFFFD166),
                child: Icon(Icons.person_rounded, color: Color(0xFF111827), size: 32),
              ),
              const SizedBox(width: 12),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('سلام قهرمان 👋', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                    Text('امروز برای بردن آماده‌ای؟', style: TextStyle(color: Colors.white60)),
                  ],
                ),
              ),
              CoinChip(value: store.coins),
            ],
          ),
          const SizedBox(height: 20),
          PremiumCard(
            padding: const EdgeInsets.all(18),
            gradient: const [Color(0xFF4C1D95), Color(0xFF0891B2)],
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(11),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(.15),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(Icons.local_fire_department_rounded, color: Color(0xFFFFD166), size: 34),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Text('لیگ هفتگی شروع شد', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                const Text('بازی کن، سکه بگیر، آیتم بخر و رکوردت را بالاتر ببر.', style: TextStyle(color: Colors.white70)),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(child: PrimaryButton(label: 'شروع سریع', icon: Icons.play_arrow_rounded, onTap: onOpenGames)),
                    const SizedBox(width: 10),
                    Expanded(child: GhostButton(label: 'سکه رایگان', icon: Icons.video_collection_rounded, onTap: () => showRewardSheet(context))),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(height: 18),
          const SectionTitle(title: 'بازی‌های پیشنهادی'),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemBuilder: (_, i) {
                final game = games[i];
                return SizedBox(width: 150, child: GameMiniCard(game: game));
              },
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemCount: min(5, games.length),
            ),
          ),
          const SizedBox(height: 18),
          const AdBannerMock(),
          const SizedBox(height: 18),
          const SectionTitle(title: 'آمار امروز'),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: StatCard(label: 'بردها', value: '${store.wins}', icon: Icons.emoji_events_rounded)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(label: 'بازی‌ها', value: '${store.gamesPlayed}', icon: Icons.sports_esports_rounded)),
              const SizedBox(width: 10),
              Expanded(child: StatCard(label: 'رکورد 2048', value: '${store.best2048}', icon: Icons.grid_4x4_rounded)),
            ],
          ),
        ],
      ),
    );
  }
}

class GamesPage extends StatelessWidget {
  const GamesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
      children: [
        const PageHeader(title: 'بازی‌ها', subtitle: 'کلاسیک، رقابتی و آماده کسب سکه'),
        const SizedBox(height: 16),
        GridView.builder(
          physics: const NeverScrollableScrollPhysics(),
          shrinkWrap: true,
          itemCount: games.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            mainAxisSpacing: 14,
            crossAxisSpacing: 14,
            childAspectRatio: .82,
          ),
          itemBuilder: (_, i) => GameGridCard(game: games[i]),
        ),
        const SizedBox(height: 20),
        const AdBannerMock(),
      ],
    );
  }
}

class LeaderboardPage extends StatelessWidget {
  const LeaderboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = GameScope.of(context);
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
        children: [
          const PageHeader(title: 'رتبه‌بندی', subtitle: 'نسخه اول: رتبه‌بندی محلی روی گوشی'),
          const SizedBox(height: 18),
          PremiumCard(
            padding: const EdgeInsets.all(18),
            gradient: const [Color(0xFF92400E), Color(0xFFB45309)],
            child: Column(
              children: [
                const Icon(Icons.workspace_premium_rounded, color: Color(0xFFFFD166), size: 54),
                const SizedBox(height: 10),
                const Text('بازیکن برتر فعلی', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
                const SizedBox(height: 6),
                Text('رکورد 2048: ${store.best2048}  •  برد: ${store.wins}', style: const TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          RankRow(rank: 1, name: 'شما', score: store.wins * 100 + store.best2048 ~/ 8 + store.coins ~/ 10),
          const RankRow(rank: 2, name: 'ربات تاکتیکی', score: 740),
          const RankRow(rank: 3, name: 'استاد منچ', score: 690),
          const RankRow(rank: 4, name: 'شاه 2048', score: 610),
          const RankRow(rank: 5, name: 'بازیکن نقطه‌خط', score: 530),
        ],
      ),
    );
  }
}

class ShopPage extends StatelessWidget {
  const ShopPage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = GameScope.of(context);
    final items = [
      ShopItem('avatar_gold', 'آواتار طلایی', 450, Icons.person_pin_rounded, 'ظاهر پروفایل ویژه'),
      ShopItem('frame_neon', 'قاب نئونی', 650, Icons.auto_awesome_rounded, 'قاب نورانی برای پروفایل'),
      ShopItem('dice_fire', 'تاس آتشین', 520, Icons.casino_rounded, 'برای منچ و ماروپله'),
      ShopItem('theme_chess', 'تم شطرنج طلایی', 780, Icons.blur_on_rounded, 'ظاهر خاص صفحه شطرنج'),
      ShopItem('win_fx', 'افکت برد', 600, Icons.celebration_rounded, 'انیمیشن برد حرفه‌ای'),
      ShopItem('bg_cyber', 'بک‌گراند سایبری', 900, Icons.wallpaper_rounded, 'حس گیمینگ بیشتر'),
    ];
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
        children: [
          PageHeader(title: 'فروشگاه', subtitle: 'سکه داری: ${store.coins}'),
          const SizedBox(height: 16),
          GridView.builder(
            physics: const NeverScrollableScrollPhysics(),
            shrinkWrap: true,
            itemCount: items.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              childAspectRatio: .86,
              crossAxisSpacing: 14,
              mainAxisSpacing: 14,
            ),
            itemBuilder: (_, i) {
              final item = items[i];
              final owned = store.ownedItems.contains(item.id);
              return PremiumCard(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFD166).withOpacity(.16),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: Icon(item.icon, color: const Color(0xFFFFD166), size: 32),
                    ),
                    const SizedBox(height: 12),
                    Text(item.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 4),
                    Expanded(child: Text(item.desc, style: const TextStyle(color: Colors.white60, fontSize: 12))),
                    Row(
                      children: [
                        Expanded(child: Text(owned ? 'خریداری شد' : '${item.price} سکه', style: TextStyle(color: owned ? Colors.greenAccent : const Color(0xFFFFD166), fontWeight: FontWeight.w800))),
                        IconButton.filled(
                          onPressed: owned
                              ? null
                              : () {
                                  final ok = store.buyItem(item.id, item.price);
                                  showSnack(context, ok ? 'آیتم با موفقیت خریداری شد' : 'سکه کافی نیست');
                                },
                          icon: Icon(owned ? Icons.check_rounded : Icons.shopping_bag_rounded),
                        ),
                      ],
                    ),
                  ],
                ),
              );
            },
          ),
          const SizedBox(height: 18),
          PrimaryButton(label: 'گرفتن سکه با تبلیغ ویدیویی', icon: Icons.play_circle_rounded, onTap: () => showRewardSheet(context)),
        ],
      ),
    );
  }
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});

  @override
  Widget build(BuildContext context) {
    final store = GameScope.of(context);
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) => ListView(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 18),
        children: [
          const PageHeader(title: 'پروفایل', subtitle: 'آمار، سطح و دارایی‌های شما'),
          const SizedBox(height: 18),
          PremiumCard(
            padding: const EdgeInsets.all(18),
            gradient: const [Color(0xFF312E81), Color(0xFF0E7490)],
            child: Row(
              children: [
                Container(
                  width: 74,
                  height: 74,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFFFD166),
                    boxShadow: [BoxShadow(color: const Color(0xFFFFD166).withOpacity(.35), blurRadius: 24)],
                  ),
                  child: const Icon(Icons.person_rounded, color: Color(0xFF111827), size: 44),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('بازیکن گیمینو', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
                      const SizedBox(height: 5),
                      Text('لیگ برنز • ${store.coins} سکه', style: const TextStyle(color: Colors.white70)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: StatCard(label: 'برد', value: '${store.wins}', icon: Icons.emoji_events_rounded)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(label: 'باخت', value: '${store.losses}', icon: Icons.flag_rounded)),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: StatCard(label: 'رکورد 2048', value: '${store.best2048}', icon: Icons.grid_4x4_rounded)),
            const SizedBox(width: 10),
            Expanded(child: StatCard(label: 'کل بازی', value: '${store.gamesPlayed}', icon: Icons.sports_esports_rounded)),
          ]),
          const SizedBox(height: 18),
          const PremiumCard(
            padding: EdgeInsets.all(16),
            child: Text('نسخه آنلاین، ورود کاربر، لیگ واقعی و ذخیره ابری در نسخه بعدی قابل اضافه شدن است.', style: TextStyle(color: Colors.white70)),
          ),
        ],
      ),
    );
  }
}

class PageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  const PageHeader({super.key, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 5),
        Text(subtitle, style: const TextStyle(color: Colors.white60)),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle({super.key, required this.title});

  @override
  Widget build(BuildContext context) {
    return Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900));
  }
}

class CoinChip extends StatelessWidget {
  final int value;
  const CoinChip({super.key, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: const Color(0xFFFFD166).withOpacity(.16),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFFFD166).withOpacity(.4)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.monetization_on_rounded, color: Color(0xFFFFD166), size: 20),
          const SizedBox(width: 5),
          Text('$value', style: const TextStyle(color: Color(0xFFFFD166), fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}

class PremiumCard extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final List<Color>? gradient;
  const PremiumCard({super.key, required this.child, this.padding = const EdgeInsets.all(12), this.gradient});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(26),
        gradient: LinearGradient(colors: gradient ?? [Colors.white.withOpacity(.095), Colors.white.withOpacity(.045)]),
        border: Border.all(color: Colors.white.withOpacity(.09)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(.28), blurRadius: 24, offset: const Offset(0, 12))],
      ),
      child: child,
    );
  }
}

class PrimaryButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const PrimaryButton({super.key, required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          gradient: const LinearGradient(colors: [Color(0xFF22C55E), Color(0xFF06B6D4)]),
          boxShadow: [BoxShadow(color: const Color(0xFF22C55E).withOpacity(.25), blurRadius: 20)],
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [Icon(icon, size: 20), const SizedBox(width: 7), Flexible(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900))),
          ],
        ),
      ),
    );
  }
}

class GhostButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onTap;
  const GhostButton({super.key, required this.label, required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(18),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(18),
          color: Colors.white.withOpacity(.09),
          border: Border.all(color: Colors.white.withOpacity(.10)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 20), const SizedBox(width: 7), Flexible(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w900)))]),
      ),
    );
  }
}

class StatCard extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});

  @override
  Widget build(BuildContext context) {
    return PremiumCard(
      padding: const EdgeInsets.all(13),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: const Color(0xFFFFD166)),
          const SizedBox(height: 8),
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          Text(label, style: const TextStyle(color: Colors.white60, fontSize: 12)),
        ],
      ),
    );
  }
}

class AdBannerMock extends StatelessWidget {
  const AdBannerMock({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 72,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(22),
        gradient: LinearGradient(colors: [Colors.white.withOpacity(.08), Colors.white.withOpacity(.03)]),
        border: Border.all(color: Colors.white.withOpacity(.08)),
      ),
      child: const Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.ads_click_rounded, color: Colors.white54),
          SizedBox(width: 8),
          Text('جایگاه تبلیغ بنری', style: TextStyle(color: Colors.white54, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }
}

void showSnack(BuildContext context, String text) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), behavior: SnackBarBehavior.floating));
}

void showRewardSheet(BuildContext context) {
  showModalBottomSheet(
    context: context,
    backgroundColor: Colors.transparent,
    builder: (_) => Directionality(
      textDirection: TextDirection.rtl,
      child: Container(
        padding: const EdgeInsets.fromLTRB(18, 16, 18, 28),
        decoration: const BoxDecoration(
          color: Color(0xFF111827),
          borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Builder(builder: (sheetContext) {
          final store = GameScope.of(context);
          return Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('دریافت سکه رایگان', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              const Text('در نسخه نهایی، این دکمه به تبلیغ ویدیویی جایزه‌ای وصل می‌شود.', style: TextStyle(color: Colors.white60)),
              const SizedBox(height: 16),
              PrimaryButton(
                label: 'تماشای تبلیغ آزمایشی و دریافت ۵۰ سکه',
                icon: Icons.play_circle_rounded,
                onTap: () {
                  store.addCoins(50, reason: 'rewarded_ad_mock');
                  Navigator.pop(sheetContext);
                  showSnack(context, '۵۰ سکه اضافه شد');
                },
              ),
              const SizedBox(height: 10),
              GhostButton(label: 'دریافت جایزه روزانه ۱۰۰ سکه', icon: Icons.card_giftcard_rounded, onTap: () {
                store.addCoins(100, reason: 'daily_reward');
                Navigator.pop(sheetContext);
                showSnack(context, 'جایزه روزانه دریافت شد');
              }),
            ],
          );
        }),
      ),
    ),
  );
}

class GameInfo {
  final String title;
  final String subtitle;
  final IconData icon;
  final List<Color> colors;
  final Widget Function() page;
  final int reward;
  const GameInfo({required this.title, required this.subtitle, required this.icon, required this.colors, required this.page, required this.reward});
}

final games = <GameInfo>[
  GameInfo(title: 'شطرنج', subtitle: 'دونفره محلی', icon: Icons.castle_rounded, colors: [Color(0xFF111827), Color(0xFFB45309)], page: () => const ChessGamePage(), reward: 90),
  GameInfo(title: 'ماروپله', subtitle: 'تاس و رقابت', icon: Icons.stairs_rounded, colors: [Color(0xFF166534), Color(0xFF0E7490)], page: () => const SnakeLadderPage(), reward: 70),
  GameInfo(title: '2048', subtitle: 'رکوردی', icon: Icons.grid_4x4_rounded, colors: [Color(0xFF7C2D12), Color(0xFFF59E0B)], page: () => const Game2048Page(), reward: 50),
  GameInfo(title: 'XOX', subtitle: 'سریع و دونفره', icon: Icons.close_rounded, colors: [Color(0xFF581C87), Color(0xFF2563EB)], page: () => const TicTacToePage(), reward: 35),
  GameInfo(title: 'دوز ۹ مهره‌ای', subtitle: 'قوانین کلاسیک', icon: Icons.adjust_rounded, colors: [Color(0xFF3F3F46), Color(0xFF854D0E)], page: () => const NineMorrisPage(), reward: 80),
  GameInfo(title: 'نقطه‌خط', subtitle: 'هوش و امتیاز', icon: Icons.linear_scale_rounded, colors: [Color(0xFF0F766E), Color(0xFF7C3AED)], page: () => const DotsBoxesPage(), reward: 60),
  GameInfo(title: 'منچ', subtitle: 'نسخه سریع', icon: Icons.casino_rounded, colors: [Color(0xFFBE123C), Color(0xFF7C3AED)], page: () => const LudoPage(), reward: 75),
];

class GameMiniCard extends StatelessWidget {
  final GameInfo game;
  const GameMiniCard({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => game.page())),
      child: PremiumCard(
        gradient: game.colors,
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(game.icon, size: 44, color: Colors.white),
            const Spacer(),
            Text(game.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
            Text(game.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 8),
            Text('+${game.reward} سکه', style: const TextStyle(color: Color(0xFFFFD166), fontWeight: FontWeight.w900)),
          ],
        ),
      ),
    );
  }
}

class GameGridCard extends StatelessWidget {
  final GameInfo game;
  const GameGridCard({super.key, required this.game});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(28),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => game.page())),
      child: PremiumCard(
        gradient: game.colors,
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Align(alignment: Alignment.centerLeft, child: CoinChip(value: game.reward)),
            const Spacer(),
            Icon(game.icon, size: 50, color: Colors.white),
            const SizedBox(height: 12),
            Text(game.title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
            Text(game.subtitle, style: const TextStyle(color: Colors.white70, fontSize: 12)),
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(16)),
              child: const Text('شروع بازی', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
            ),
          ],
        ),
      ),
    );
  }
}

class ShopItem {
  final String id;
  final String title;
  final int price;
  final IconData icon;
  final String desc;
  ShopItem(this.id, this.title, this.price, this.icon, this.desc);
}

class RankRow extends StatelessWidget {
  final int rank;
  final String name;
  final int score;
  const RankRow({super.key, required this.rank, required this.name, required this.score});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.07),
        borderRadius: BorderRadius.circular(22),
        border: Border.all(color: Colors.white.withOpacity(.08)),
      ),
      child: Row(
        children: [
          CircleAvatar(backgroundColor: rank <= 3 ? const Color(0xFFFFD166) : Colors.white12, child: Text('$rank', style: TextStyle(color: rank <= 3 ? const Color(0xFF111827) : Colors.white, fontWeight: FontWeight.w900))),
          const SizedBox(width: 12),
          Expanded(child: Text(name, style: const TextStyle(fontWeight: FontWeight.w900))),
          Text('$score امتیاز', style: const TextStyle(color: Colors.white70)),
        ],
      ),
    );
  }
}

class GameScaffold extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  final List<Widget>? actions;
  const GameScaffold({super.key, required this.title, required this.subtitle, required this.child, this.actions});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const Positioned.fill(child: PremiumBackground()),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(12, 10, 12, 8),
                  child: Row(
                    children: [
                      IconButton.filledTonal(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_rounded)),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(title, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w900)),
                            Text(subtitle, style: const TextStyle(color: Colors.white60, fontSize: 12)),
                          ],
                        ),
                      ),
                      ...?actions,
                    ],
                  ),
                ),
                Expanded(child: child),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------- XOX ----------------------
class TicTacToePage extends StatefulWidget {
  const TicTacToePage({super.key});

  @override
  State<TicTacToePage> createState() => _TicTacToePageState();
}

class _TicTacToePageState extends State<TicTacToePage> {
  List<String> board = List.filled(9, '');
  String turn = 'X';
  String message = 'نوبت X';
  bool ended = false;
  bool robot = false;

  void reset() {
    setState(() {
      board = List.filled(9, '');
      turn = 'X';
      message = 'نوبت X';
      ended = false;
    });
  }

  void play(int i) {
    if (ended || board[i].isNotEmpty) return;
    setState(() => board[i] = turn);
    final win = winner();
    if (win != null) return finish(win);
    if (!board.contains('')) return finish('draw');
    setState(() {
      turn = turn == 'X' ? 'O' : 'X';
      message = 'نوبت $turn';
    });
    if (robot && turn == 'O') Future.delayed(const Duration(milliseconds: 350), robotPlay);
  }

  void robotPlay() {
    if (ended) return;
    final empty = [for (int i = 0; i < 9; i++) if (board[i].isEmpty) i];
    if (empty.isEmpty) return;
    int choice = empty.first;
    for (final i in empty) {
      final copy = [...board]..[i] = 'O';
      if (_winner(copy) == 'O') choice = i;
    }
    play(choice);
  }

  String? winner() => _winner(board);

  String? _winner(List<String> b) {
    const lines = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (final l in lines) {
      if (b[l[0]].isNotEmpty && b[l[0]] == b[l[1]] && b[l[1]] == b[l[2]]) return b[l[0]];
    }
    return null;
  }

  void finish(String result) {
    final store = GameScope.of(context);
    setState(() {
      ended = true;
      message = result == 'draw' ? 'بازی مساوی شد' : 'برنده: $result';
    });
    if (result == 'X') store.recordWin(reward: 35);
    if (result == 'O') store.recordLoss();
  }

  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: 'XOX',
      subtitle: 'بازی سریع، دونفره یا با ربات ساده',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(
            padding: const EdgeInsets.all(16),
            child: Row(children: [Expanded(child: Text(message, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))), Switch(value: robot, onChanged: (v) => setState(() { robot = v; reset(); })), const Text('ربات')]),
          ),
          const SizedBox(height: 18),
          AspectRatio(
            aspectRatio: 1,
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 9,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 10, crossAxisSpacing: 10),
              itemBuilder: (_, i) => InkWell(
                borderRadius: BorderRadius.circular(26),
                onTap: () => play(i),
                child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(26),
                    gradient: LinearGradient(colors: [Colors.white.withOpacity(.12), Colors.white.withOpacity(.05)]),
                    border: Border.all(color: Colors.white.withOpacity(.08)),
                  ),
                  child: Center(child: Text(board[i], style: TextStyle(fontSize: 58, fontWeight: FontWeight.w900, color: board[i] == 'X' ? const Color(0xFF00D4FF) : const Color(0xFFFFD166)))),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------- 2048 ----------------------
class Game2048Page extends StatefulWidget {
  const Game2048Page({super.key});

  @override
  State<Game2048Page> createState() => _Game2048PageState();
}

class _Game2048PageState extends State<Game2048Page> {
  final rand = Random();
  List<List<int>> grid = List.generate(4, (_) => List.filled(4, 0));
  int score = 0;

  @override
  void initState() {
    super.initState();
    reset();
  }

  void reset() {
    grid = List.generate(4, (_) => List.filled(4, 0));
    score = 0;
    addTile();
    addTile();
    setState(() {});
  }

  void addTile() {
    final empty = <Point<int>>[];
    for (int r = 0; r < 4; r++) {
      for (int c = 0; c < 4; c++) {
        if (grid[r][c] == 0) empty.add(Point(r, c));
      }
    }
    if (empty.isEmpty) return;
    final p = empty[rand.nextInt(empty.length)];
    grid[p.x][p.y] = rand.nextDouble() < .9 ? 2 : 4;
  }

  List<int> mergeLine(List<int> line) {
    final values = line.where((e) => e != 0).toList();
    final result = <int>[];
    for (int i = 0; i < values.length; i++) {
      if (i + 1 < values.length && values[i] == values[i + 1]) {
        final v = values[i] * 2;
        result.add(v);
        score += v;
        i++;
      } else {
        result.add(values[i]);
      }
    }
    while (result.length < 4) result.add(0);
    return result;
  }

  void move(String dir) {
    final before = grid.map((e) => e.join(',')).join('|');
    if (dir == 'left') {
      for (int r = 0; r < 4; r++) grid[r] = mergeLine(grid[r]);
    } else if (dir == 'right') {
      for (int r = 0; r < 4; r++) grid[r] = mergeLine(grid[r].reversed.toList()).reversed.toList();
    } else if (dir == 'up') {
      for (int c = 0; c < 4; c++) {
        final merged = mergeLine([for (int r = 0; r < 4; r++) grid[r][c]]);
        for (int r = 0; r < 4; r++) grid[r][c] = merged[r];
      }
    } else if (dir == 'down') {
      for (int c = 0; c < 4; c++) {
        final merged = mergeLine([for (int r = 3; r >= 0; r--) grid[r][c]]);
        for (int r = 3, i = 0; r >= 0; r--, i++) grid[r][c] = merged[i];
      }
    }
    final after = grid.map((e) => e.join(',')).join('|');
    if (before != after) {
      addTile();
      GameScope.of(context).updateBest2048(score);
      setState(() {});
    }
  }

  Color tileColor(int v) {
    if (v == 0) return Colors.white.withOpacity(.06);
    final palette = [const Color(0xFF374151), const Color(0xFF0E7490), const Color(0xFF7C3AED), const Color(0xFFB45309), const Color(0xFFBE123C), const Color(0xFF16A34A)];
    return palette[(log(v) / log(2)).floor() % palette.length];
  }

  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: '2048',
      subtitle: 'رکورد بزن و سکه بگیر',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(padding: const EdgeInsets.all(16), child: Row(children: [Expanded(child: Text('امتیاز: $score', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900))), Text('بهترین: ${GameScope.of(context).best2048}', style: const TextStyle(color: Color(0xFFFFD166), fontWeight: FontWeight.w800))])),
          const SizedBox(height: 18),
          GestureDetector(
            onPanEnd: (d) {
              final v = d.velocity.pixelsPerSecond;
              if (v.dx.abs() > v.dy.abs()) {
                move(v.dx > 0 ? 'right' : 'left');
              } else {
                move(v.dy > 0 ? 'down' : 'up');
              }
            },
            child: AspectRatio(
              aspectRatio: 1,
              child: Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(color: Colors.black.withOpacity(.24), borderRadius: BorderRadius.circular(28), border: Border.all(color: Colors.white.withOpacity(.08))),
                child: GridView.builder(
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: 16,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 4, mainAxisSpacing: 8, crossAxisSpacing: 8),
                  itemBuilder: (_, i) {
                    final v = grid[i ~/ 4][i % 4];
                    return AnimatedContainer(
                      duration: const Duration(milliseconds: 120),
                      decoration: BoxDecoration(color: tileColor(v), borderRadius: BorderRadius.circular(18), boxShadow: v == 0 ? [] : [BoxShadow(color: tileColor(v).withOpacity(.35), blurRadius: 18)]),
                      child: Center(child: Text(v == 0 ? '' : '$v', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
                    );
                  },
                ),
              ),
            ),
          ),
          const SizedBox(height: 16),
          Row(children: [
            Expanded(child: GhostButton(label: 'بالا', icon: Icons.keyboard_arrow_up_rounded, onTap: () => move('up'))),
            const SizedBox(width: 8),
            Expanded(child: GhostButton(label: 'پایین', icon: Icons.keyboard_arrow_down_rounded, onTap: () => move('down'))),
          ]),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: GhostButton(label: 'راست', icon: Icons.keyboard_arrow_right_rounded, onTap: () => move('right'))),
            const SizedBox(width: 8),
            Expanded(child: GhostButton(label: 'چپ', icon: Icons.keyboard_arrow_left_rounded, onTap: () => move('left'))),
          ]),
        ],
      ),
    );
  }
}

// ---------------------- Snake & Ladder ----------------------
class SnakeLadderPage extends StatefulWidget {
  const SnakeLadderPage({super.key});

  @override
  State<SnakeLadderPage> createState() => _SnakeLadderPageState();
}

class _SnakeLadderPageState extends State<SnakeLadderPage> {
  final rand = Random();
  List<int> pos = [1, 1, 1, 1];
  int players = 2;
  int turn = 0;
  int dice = 1;
  String msg = 'تاس بریز';
  final Map<int, int> jumps = {4: 25, 13: 46, 33: 49, 42: 63, 50: 69, 62: 81, 74: 92, 27: 5, 40: 3, 54: 31, 66: 45, 89: 53, 99: 41};

  void reset() => setState(() { pos = [1, 1, 1, 1]; turn = 0; dice = 1; msg = 'تاس بریز'; });

  void roll() {
    dice = rand.nextInt(6) + 1;
    int next = min(100, pos[turn] + dice);
    if (jumps.containsKey(next)) next = jumps[next]!;
    pos[turn] = next;
    if (next == 100) {
      msg = 'بازیکن ${turn + 1} برنده شد';
      GameScope.of(context).recordWin(reward: 70);
    } else {
      turn = (turn + 1) % players;
      msg = 'نوبت بازیکن ${turn + 1}';
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: 'ماروپله',
      subtitle: '۲ تا ۴ بازیکن، تاس و خانه‌های ویژه',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(14),
            child: PremiumCard(
              padding: const EdgeInsets.all(14),
              child: Row(children: [
                Expanded(child: Text(msg, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
                DropdownButton<int>(value: players, items: [2, 3, 4].map((e) => DropdownMenuItem(value: e, child: Text('$e نفره'))).toList(), onChanged: (v) => setState(() { players = v ?? 2; reset(); })),
                const SizedBox(width: 8),
                FilledButton.icon(onPressed: msg.contains('برنده') ? null : roll, icon: const Icon(Icons.casino_rounded), label: Text('$dice')),
              ]),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: GridView.builder(
                itemCount: 100,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 10, mainAxisSpacing: 3, crossAxisSpacing: 3),
                itemBuilder: (_, i) {
                  final row = i ~/ 10;
                  final col = i % 10;
                  final n = 100 - row * 10 - (row.isEven ? col : 9 - col);
                  final here = [for (int p = 0; p < players; p++) if (pos[p] == n) p + 1];
                  final jump = jumps[n];
                  return Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: jump == null ? Colors.white.withOpacity(.07) : (jump > n ? Colors.green.withOpacity(.35) : Colors.red.withOpacity(.35)),
                      border: Border.all(color: Colors.white.withOpacity(.06)),
                    ),
                    child: Stack(
                      children: [
                        Positioned(top: 2, right: 3, child: Text('$n', style: const TextStyle(fontSize: 8, color: Colors.white54))),
                        Center(child: Wrap(spacing: 1, children: here.map((p) => CircleAvatar(radius: 6, child: Text('$p', style: const TextStyle(fontSize: 8)))).toList())),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ---------------------- Dots and Boxes ----------------------
class DotsBoxesPage extends StatefulWidget {
  const DotsBoxesPage({super.key});

  @override
  State<DotsBoxesPage> createState() => _DotsBoxesPageState();
}

class _DotsBoxesPageState extends State<DotsBoxesPage> {
  static const int n = 5;
  late List<List<int>> h;
  late List<List<int>> v;
  late List<List<int>> box;
  int turn = 1;
  String msg = 'نوبت بازیکن ۱';

  @override
  void initState() { super.initState(); reset(); }
  void reset() => setState(() { h = List.generate(n, (_) => List.filled(n - 1, 0)); v = List.generate(n - 1, (_) => List.filled(n, 0)); box = List.generate(n - 1, (_) => List.filled(n - 1, 0)); turn = 1; msg = 'نوبت بازیکن ۱'; });

  void mark(bool horizontal, int r, int c) {
    if (horizontal) {
      if (h[r][c] != 0) return;
      h[r][c] = turn;
    } else {
      if (v[r][c] != 0) return;
      v[r][c] = turn;
    }
    int made = 0;
    for (int br = 0; br < n - 1; br++) {
      for (int bc = 0; bc < n - 1; bc++) {
        if (box[br][bc] == 0 && h[br][bc] != 0 && h[br + 1][bc] != 0 && v[br][bc] != 0 && v[br][bc + 1] != 0) {
          box[br][bc] = turn;
          made++;
        }
      }
    }
    if (made == 0) turn = turn == 1 ? 2 : 1;
    final scores = score();
    final complete = scores[0] + scores[1] == (n - 1) * (n - 1);
    if (complete) {
      msg = scores[0] == scores[1] ? 'مساوی شد' : 'برنده بازیکن ${scores[0] > scores[1] ? 1 : 2}';
      if (scores[0] > scores[1]) GameScope.of(context).recordWin(reward: 60); else GameScope.of(context).recordLoss();
    } else {
      msg = made > 0 ? 'خانه گرفتی؛ دوباره بازیکن $turn' : 'نوبت بازیکن $turn';
    }
    setState(() {});
  }

  List<int> score() {
    int a = 0, b = 0;
    for (final row in box) { for (final x in row) { if (x == 1) a++; if (x == 2) b++; } }
    return [a, b];
  }

  @override
  Widget build(BuildContext context) {
    final s = score();
    return GameScaffold(
      title: 'نقطه‌خط',
      subtitle: 'خط بکش، مربع بگیر، امتیاز جمع کن',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(padding: const EdgeInsets.all(16), child: Row(children: [Expanded(child: Text(msg, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18))), Text('${s[0]} - ${s[1]}', style: const TextStyle(color: Color(0xFFFFD166), fontSize: 20, fontWeight: FontWeight.w900))])),
          const SizedBox(height: 16),
          AspectRatio(
            aspectRatio: 1,
            child: GestureDetector(
              onTapDown: (d) {
                final boxSize = context.size?.width ?? 320;
                final pad = boxSize * .08;
                final step = (boxSize - pad * 2) / (n - 1);
                final x = d.localPosition.dx;
                final y = d.localPosition.dy;
                double best = 9999;
                bool bh = true;
                int br = 0, bc = 0;
                for (int r = 0; r < n; r++) {
                  for (int c = 0; c < n - 1; c++) {
                    final x1 = pad + c * step, x2 = pad + (c + 1) * step, yy = pad + r * step;
                    if (x >= x1 && x <= x2) {
                      final dist = (y - yy).abs();
                      if (dist < best) { best = dist; bh = true; br = r; bc = c; }
                    }
                  }
                }
                for (int r = 0; r < n - 1; r++) {
                  for (int c = 0; c < n; c++) {
                    final xx = pad + c * step, y1 = pad + r * step, y2 = pad + (r + 1) * step;
                    if (y >= y1 && y <= y2) {
                      final dist = (x - xx).abs();
                      if (dist < best) { best = dist; bh = false; br = r; bc = c; }
                    }
                  }
                }
                if (best < 22) mark(bh, br, bc);
              },
              child: CustomPaint(painter: DotsPainter(h, v, box)),
            ),
          ),
        ],
      ),
    );
  }
}

class DotsPainter extends CustomPainter {
  final List<List<int>> h;
  final List<List<int>> v;
  final List<List<int>> box;
  DotsPainter(this.h, this.v, this.box);
  @override
  void paint(Canvas canvas, Size size) {
    const n = 5;
    final pad = size.width * .08;
    final step = (size.width - pad * 2) / (n - 1);
    final base = Paint()..strokeWidth = 5..strokeCap = StrokeCap.round..color = Colors.white24;
    final p1 = Paint()..strokeWidth = 6..strokeCap = StrokeCap.round..color = const Color(0xFF00D4FF);
    final p2 = Paint()..strokeWidth = 6..strokeCap = StrokeCap.round..color = const Color(0xFFFFD166);
    final fill1 = Paint()..color = const Color(0xFF00D4FF).withOpacity(.18);
    final fill2 = Paint()..color = const Color(0xFFFFD166).withOpacity(.18);
    for (int r = 0; r < n - 1; r++) {
      for (int c = 0; c < n - 1; c++) {
        if (box[r][c] != 0) canvas.drawRRect(RRect.fromRectAndRadius(Rect.fromLTWH(pad + c * step + 8, pad + r * step + 8, step - 16, step - 16), const Radius.circular(16)), box[r][c] == 1 ? fill1 : fill2);
      }
    }
    for (int r = 0; r < n; r++) {
      for (int c = 0; c < n - 1; c++) {
        final paint = h[r][c] == 0 ? base : (h[r][c] == 1 ? p1 : p2);
        canvas.drawLine(Offset(pad + c * step, pad + r * step), Offset(pad + (c + 1) * step, pad + r * step), paint);
      }
    }
    for (int r = 0; r < n - 1; r++) {
      for (int c = 0; c < n; c++) {
        final paint = v[r][c] == 0 ? base : (v[r][c] == 1 ? p1 : p2);
        canvas.drawLine(Offset(pad + c * step, pad + r * step), Offset(pad + c * step, pad + (r + 1) * step), paint);
      }
    }
    final dot = Paint()..color = Colors.white;
    for (int r = 0; r < n; r++) { for (int c = 0; c < n; c++) { canvas.drawCircle(Offset(pad + c * step, pad + r * step), 7, dot); } }
  }
  @override
  bool shouldRepaint(covariant DotsPainter oldDelegate) => true;
}

// ---------------------- Nine Men's Morris ----------------------
class NineMorrisPage extends StatefulWidget {
  const NineMorrisPage({super.key});

  @override
  State<NineMorrisPage> createState() => _NineMorrisPageState();
}

class _NineMorrisPageState extends State<NineMorrisPage> {
  List<int> board = List.filled(24, 0);
  List<int> toPlace = [9, 9];
  int turn = 1;
  int? selected;
  bool removeMode = false;
  String msg = 'بازیکن ۱ مهره بگذارد';

  final List<List<int>> mills = const [
    [0,1,2],[3,4,5],[6,7,8],[9,10,11],[12,13,14],[15,16,17],[18,19,20],[21,22,23],
    [0,9,21],[3,10,18],[6,11,15],[1,4,7],[16,19,22],[8,12,17],[5,13,20],[2,14,23]
  ];
  final List<List<int>> adj = const [
    [1,9],[0,2,4],[1,14],[4,10],[1,3,5,7],[4,13],[7,11],[4,6,8],[7,12],[0,10,21],[3,9,11,18],[6,10,15],
    [8,13,17],[5,12,14,20],[2,13,23],[11,16],[15,17,19],[12,16],[10,19],[16,18,20,22],[13,19],[9,22],[19,21,23],[14,22]
  ];

  void reset() => setState(() { board = List.filled(24, 0); toPlace = [9,9]; turn = 1; selected = null; removeMode = false; msg = 'بازیکن ۱ مهره بگذارد'; });

  bool makesMill(int p, int player) => mills.any((m) => m.contains(p) && m.every((x) => board[x] == player));

  int pieces(int player) => board.where((e) => e == player).length;

  void tap(int i) {
    if (removeMode) {
      if (board[i] == other(turn)) {
        board[i] = 0;
        removeMode = false;
        if (toPlace[0] == 0 && toPlace[1] == 0 && pieces(other(turn)) < 3) {
          msg = 'بازیکن $turn برنده شد';
          GameScope.of(context).recordWin(reward: 80);
        } else {
          turn = other(turn);
          msg = 'نوبت بازیکن $turn';
        }
      }
      setState(() {});
      return;
    }
    if (toPlace[turn - 1] > 0) {
      if (board[i] != 0) return;
      board[i] = turn;
      toPlace[turn - 1]--;
      if (makesMill(i, turn)) { removeMode = true; msg = 'دوز ساخته شد؛ یک مهره حریف را حذف کن'; }
      else { turn = other(turn); msg = 'نوبت بازیکن $turn'; }
      setState(() {});
      return;
    }
    if (selected == null) {
      if (board[i] == turn) selected = i;
    } else {
      final canFly = pieces(turn) == 3;
      if (board[i] == 0 && (canFly || adj[selected!].contains(i))) {
        board[selected!] = 0;
        board[i] = turn;
        if (makesMill(i, turn)) { removeMode = true; msg = 'دوز ساخته شد؛ مهره حریف را حذف کن'; }
        else { turn = other(turn); msg = 'نوبت بازیکن $turn'; }
        selected = null;
      } else if (board[i] == turn) {
        selected = i;
      }
    }
    setState(() {});
  }

  int other(int p) => p == 1 ? 2 : 1;

  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: 'دوز ۹ مهره‌ای',
      subtitle: 'چیدن، حرکت دادن و حذف مهره',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(padding: const EdgeInsets.all(16), child: Text(msg, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          const SizedBox(height: 16),
          AspectRatio(
            aspectRatio: 1,
            child: GestureDetector(
              onTapDown: (d) {
                final points = morrisPoints(Size(context.size?.width ?? 360, context.size?.width ?? 360));
                int best = -1;
                double dist = 9999;
                for (int i = 0; i < points.length; i++) {
                  final dd = (points[i] - d.localPosition).distance;
                  if (dd < dist) { dist = dd; best = i; }
                }
                if (dist < 28) tap(best);
              },
              child: CustomPaint(painter: MorrisPainter(board, selected)),
            ),
          ),
          const SizedBox(height: 12),
          Text('باقی‌مانده برای چیدن: بازیکن۱ ${toPlace[0]} مهره، بازیکن۲ ${toPlace[1]} مهره', style: const TextStyle(color: Colors.white60)),
        ],
      ),
    );
  }
}

List<Offset> morrisPoints(Size size) {
  final s = min(size.width, size.height);
  final c = Offset(size.width / 2, size.height / 2);
  final margins = [s * .08, s * .22, s * .36];
  final pts = <Offset>[];
  for (final m in margins) {
    final l = m, r = s - m, t = m, b = s - m, mid = s / 2;
    pts.addAll([Offset(l,t), Offset(mid,t), Offset(r,t), Offset(l,mid), Offset(mid - (mid-l)/2, mid), Offset(r,mid), Offset(l,b), Offset(mid,b), Offset(r,b)]);
  }
  // Reorder to standard 24 compact list matching adjacency enough for gameplay.
  return [
    Offset(margins[0],margins[0]), Offset(s/2,margins[0]), Offset(s-margins[0],margins[0]),
    Offset(margins[1],margins[1]), Offset(s/2,margins[1]), Offset(s-margins[1],margins[1]),
    Offset(margins[2],margins[2]), Offset(s/2,margins[2]), Offset(s-margins[2],margins[2]),
    Offset(margins[0],s/2), Offset(margins[1],s/2), Offset(margins[2],s/2),
    Offset(s-margins[2],s/2), Offset(s-margins[1],s/2), Offset(s-margins[0],s/2),
    Offset(margins[2],s-margins[2]), Offset(s/2,s-margins[2]), Offset(s-margins[2],s-margins[2]),
    Offset(margins[1],s-margins[1]), Offset(s/2,s-margins[1]), Offset(s-margins[1],s-margins[1]),
    Offset(margins[0],s-margins[0]), Offset(s/2,s-margins[0]), Offset(s-margins[0],s-margins[0]),
  ].map((p) => p + Offset((size.width - s) / 2, (size.height - s) / 2)).toList();
}

class MorrisPainter extends CustomPainter {
  final List<int> board;
  final int? selected;
  MorrisPainter(this.board, this.selected);
  @override
  void paint(Canvas canvas, Size size) {
    final pts = morrisPoints(size);
    final line = Paint()..color = Colors.white30..strokeWidth = 4;
    void draw(List<int> xs) { for (int i = 0; i < xs.length - 1; i++) canvas.drawLine(pts[xs[i]], pts[xs[i+1]], line); }
    draw([0,1,2,14,23,22,21,9,0]);
    draw([3,4,5,13,20,19,18,10,3]);
    draw([6,7,8,12,17,16,15,11,6]);
    draw([1,4,7]); draw([16,19,22]); draw([9,10,11]); draw([12,13,14]);
    for (int i = 0; i < pts.length; i++) {
      if (selected == i) canvas.drawCircle(pts[i], 21, Paint()..color = const Color(0xFF22C55E).withOpacity(.35));
      canvas.drawCircle(pts[i], 9, Paint()..color = Colors.white);
      if (board[i] != 0) canvas.drawCircle(pts[i], 18, Paint()..color = board[i] == 1 ? const Color(0xFF00D4FF) : const Color(0xFFFFD166));
    }
  }
  @override
  bool shouldRepaint(covariant MorrisPainter oldDelegate) => true;
}

// ---------------------- Ludo Quick ----------------------
class LudoPage extends StatefulWidget {
  const LudoPage({super.key});
  @override
  State<LudoPage> createState() => _LudoPageState();
}

class _LudoPageState extends State<LudoPage> {
  final rand = Random();
  List<int> pos = [-1, -1, -1, -1];
  int turn = 0;
  int dice = 1;
  String msg = 'برای شروع باید ۶ بیاوری';
  void reset() => setState(() { pos = [-1,-1,-1,-1]; turn = 0; dice = 1; msg = 'برای شروع باید ۶ بیاوری'; });
  void roll() {
    dice = rand.nextInt(6)+1;
    if (pos[turn] == -1) {
      if (dice == 6) { pos[turn] = 0; msg = 'بازیکن ${turn+1} وارد شد'; }
      else { msg = 'بازیکن ${turn+1} نتوانست وارد شود'; turn = (turn+1)%4; }
    } else {
      pos[turn] = min(56, pos[turn] + dice);
      for (int i=0;i<4;i++) { if (i != turn && pos[i] == pos[turn] && ![0,8,13,21,26,34,39,47].contains(pos[i])) pos[i] = -1; }
      if (pos[turn] >= 56) { msg = 'بازیکن ${turn+1} برنده شد'; GameScope.of(context).recordWin(reward: 75); }
      else { if (dice != 6) turn = (turn+1)%4; msg = 'نوبت بازیکن ${turn+1}'; }
    }
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: 'منچ',
      subtitle: 'نسخه سریع ۴ بازیکن با شروع ۶ و زدن مهره',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(padding: const EdgeInsets.all(16), child: Row(children: [Expanded(child: Text(msg, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))), FilledButton.icon(onPressed: msg.contains('برنده') ? null : roll, icon: const Icon(Icons.casino_rounded), label: Text('$dice'))])),
          const SizedBox(height: 18),
          AspectRatio(aspectRatio: 1, child: CustomPaint(painter: LudoPainter(pos, turn))),
          const SizedBox(height: 12),
          const Text('این نسخه برای شروع، منچ سریع و سبک است. نسخه کامل ۴ مهره‌ای و آنلاین می‌تواند در آپدیت بعدی اضافه شود.', style: TextStyle(color: Colors.white60)),
        ],
      ),
    );
  }
}

class LudoPainter extends CustomPainter {
  final List<int> pos;
  final int turn;
  LudoPainter(this.pos, this.turn);
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width/2, size.height/2);
    final r = size.width*.38;
    final colors = [Colors.redAccent, Colors.blueAccent, Colors.greenAccent, Colors.amberAccent];
    final track = Paint()..color = Colors.white.withOpacity(.12)..style = PaintingStyle.stroke..strokeWidth = 28;
    canvas.drawCircle(c, r, track);
    for (int i=0;i<56;i++) {
      final a = -pi/2 + i/56*2*pi;
      final p = c + Offset(cos(a)*r, sin(a)*r);
      canvas.drawCircle(p, 4, Paint()..color = Colors.white30);
    }
    for (int p=0;p<4;p++) {
      final home = Offset((p==0||p==3)?size.width*.2:size.width*.8, (p<2)?size.height*.2:size.height*.8);
      canvas.drawCircle(home, 34, Paint()..color = colors[p].withOpacity(.25));
      final idx = pos[p];
      final token = idx < 0 ? home : c + Offset(cos(-pi/2 + idx/56*2*pi)*r, sin(-pi/2 + idx/56*2*pi)*r);
      canvas.drawCircle(token, p == turn ? 18 : 15, Paint()..color = colors[p]);
      final tp = TextPainter(text: TextSpan(text: '${p+1}', style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, token - Offset(tp.width/2, tp.height/2));
    }
  }
  @override
  bool shouldRepaint(covariant LudoPainter oldDelegate) => true;
}

// ---------------------- Chess Local ----------------------
class ChessGamePage extends StatefulWidget {
  const ChessGamePage({super.key});
  @override
  State<ChessGamePage> createState() => _ChessGamePageState();
}

class _ChessGamePageState extends State<ChessGamePage> {
  late List<List<String>> b;
  bool whiteTurn = true;
  Point<int>? selected;
  String msg = 'نوبت سفید';
  @override
  void initState() { super.initState(); reset(); }
  void reset() {
    b = [
      ['br','bn','bb','bq','bk','bb','bn','br'],
      List.filled(8,'bp'),
      List.filled(8,''), List.filled(8,''), List.filled(8,''), List.filled(8,''),
      List.filled(8,'wp'),
      ['wr','wn','wb','wq','wk','wb','wn','wr'],
    ];
    whiteTurn = true; selected = null; msg = 'نوبت سفید'; setState((){});
  }
  String symbol(String p) {
    const m = {'wk':'♔','wq':'♕','wr':'♖','wb':'♗','wn':'♘','wp':'♙','bk':'♚','bq':'♛','br':'♜','bb':'♝','bn':'♞','bp':'♟'};
    return m[p] ?? '';
  }
  bool isWhite(String p) => p.startsWith('w');
  bool clearPath(Point<int> a, Point<int> to) {
    final dr = (to.x - a.x).sign, dc = (to.y - a.y).sign;
    int r = a.x + dr, c = a.y + dc;
    while (r != to.x || c != to.y) { if (b[r][c].isNotEmpty) return false; r += dr; c += dc; }
    return true;
  }
  bool legal(Point<int> a, Point<int> to) {
    final p = b[a.x][a.y]; if (p.isEmpty) return false;
    final target = b[to.x][to.y]; if (target.isNotEmpty && isWhite(target) == isWhite(p)) return false;
    final dr = to.x - a.x, dc = to.y - a.y, adr = dr.abs(), adc = dc.abs();
    final type = p[1];
    if (type == 'p') {
      final dir = isWhite(p) ? -1 : 1;
      final start = isWhite(p) ? 6 : 1;
      if (dc == 0 && target.isEmpty && dr == dir) return true;
      if (dc == 0 && target.isEmpty && a.x == start && dr == 2*dir && b[a.x+dir][a.y].isEmpty) return true;
      if (adc == 1 && dr == dir && target.isNotEmpty && isWhite(target) != isWhite(p)) return true;
      return false;
    }
    if (type == 'n') return (adr == 2 && adc == 1) || (adr == 1 && adc == 2);
    if (type == 'b') return adr == adc && clearPath(a, to);
    if (type == 'r') return (adr == 0 || adc == 0) && clearPath(a, to);
    if (type == 'q') return (adr == adc || adr == 0 || adc == 0) && clearPath(a, to);
    if (type == 'k') return adr <= 1 && adc <= 1;
    return false;
  }
  void tap(int r, int c) {
    final p = b[r][c];
    if (selected == null) {
      if (p.isNotEmpty && isWhite(p) == whiteTurn) setState(() => selected = Point(r,c));
      return;
    }
    final from = selected!;
    if (from.x == r && from.y == c) { setState(() => selected = null); return; }
    if (legal(from, Point(r,c))) {
      final captured = b[r][c];
      b[r][c] = b[from.x][from.y]; b[from.x][from.y] = '';
      if (captured.endsWith('k')) { msg = whiteTurn ? 'سفید برنده شد' : 'سیاه برنده شد'; GameScope.of(context).recordWin(reward: 90); }
      else { whiteTurn = !whiteTurn; msg = whiteTurn ? 'نوبت سفید' : 'نوبت سیاه'; }
      selected = null; setState((){});
    } else {
      setState(() { msg = 'حرکت غیرمجاز'; selected = null; });
    }
  }
  @override
  Widget build(BuildContext context) {
    return GameScaffold(
      title: 'شطرنج',
      subtitle: 'حرکت‌های استاندارد مهره‌ها؛ نسخه محلی',
      actions: [IconButton.filledTonal(onPressed: reset, icon: const Icon(Icons.refresh_rounded))],
      child: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          PremiumCard(padding: const EdgeInsets.all(16), child: Text(msg, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          const SizedBox(height: 18),
          AspectRatio(
            aspectRatio: 1,
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              itemCount: 64,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 8),
              itemBuilder: (_, i) {
                final r=i~/8,c=i%8;
                final dark=(r+c).isOdd;
                final sel=selected?.x==r&&selected?.y==c;
                return InkWell(
                  onTap: () => tap(r,c),
                  child: Container(
                    color: sel ? const Color(0xFF22C55E) : (dark ? const Color(0xFF7C4A21) : const Color(0xFFE8C99B)),
                    child: Center(child: Text(symbol(b[r][c]), style: TextStyle(fontSize: 32, color: b[r][c].startsWith('w') ? Colors.white : Colors.black, shadows: const [Shadow(color: Colors.black54, blurRadius: 2)]))),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 12),
          const Text('این نسخه حرکت مهره‌ها، گرفتن مهره و برد با گرفتن شاه را دارد. کیش/مات کامل و قلعه‌رفتن در نسخه پیشرفته قابل اضافه شدن است.', style: TextStyle(color: Colors.white60)),
        ],
      ),
    );
  }
}
