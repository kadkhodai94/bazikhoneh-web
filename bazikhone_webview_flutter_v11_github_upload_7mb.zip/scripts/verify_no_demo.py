from pathlib import Path
p = Path('lib/main.dart')
text = p.read_text(encoding='utf-8')
for bad in ['Flutter Demo Home Page', 'MyHomePage', '_counter']:
    if bad in text:
        raise SystemExit(f'Default Flutter demo text found: {bad}')
if 'WebViewWidget' not in text or 'assets/game.html' not in text:
    raise SystemExit('Expected WebView app code not found.')
print('OK: WebView app verified, no Flutter demo code found.')
