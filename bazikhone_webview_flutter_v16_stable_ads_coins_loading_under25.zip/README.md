Bazi Khone WebView v16 - stable rewarded ads, banner restore, coin store sync, custom loading.
