import 'dart:convert';
import 'dart:io' show Platform;

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:webview_flutter/webview_flutter.dart';

const String _adiveryAppId = 'aa714944-d43d-43d4-9d36-1cb3404cefbc';
const String _bannerPlacementId = '2982cc2e-11c7-4051-80cc-6149a623000a';
const String _rewardedPlacementId = '5d4c9b82-8d02-4978-859a-04368264e1cb';
const String _interstitialPlacementId = '814de6e1-7ca3-4c30-8656-1eb165307232';
const String _gameStartCounterKey = 'game_start_counter_v1';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  _safeInitAdivery();
  runApp(const BaziKhoneWebViewApp());
}

void _safeInitAdivery() {
  if (!Platform.isAndroid) return;
  try {
    AdiveryPlugin.initialize(_adiveryAppId);
    AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
  } catch (_) {
    // Build and app startup should never fail if the ad SDK is not ready.
  }
}

class BaziKhoneWebViewApp extends StatelessWidget {
  const BaziKhoneWebViewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: GameWebViewScreen(),
    );
  }
}

class GameWebViewScreen extends StatefulWidget {
  const GameWebViewScreen({super.key});

  @override
  State<GameWebViewScreen> createState() => _GameWebViewScreenState();
}

class _GameWebViewScreenState extends State<GameWebViewScreen> {
  late final WebViewController _controller;
  var _loading = true;
  var _showChrome = true;
  Rect? _inlineBannerRect;
  int _pendingRewardAmount = 0;
  String _pendingRewardLabel = 'پاداش تبلیغ ویدئویی';
  bool _adiveryListenerAttached = false;
  late final Widget _adiveryBannerWidget;

  @override
  void initState() {
    super.initState();
    _adiveryBannerWidget = Platform.isAndroid
        ? BannerAd(_bannerPlacementId, BannerAdSize.BANNER)
        : const SizedBox.shrink();
    _setupAdiveryRewardListener();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0x00000000))
      ..addJavaScriptChannel(
        'BaziBridge',
        onMessageReceived: (JavaScriptMessage message) {
          if (message.message == 'game_start') {
            _handleGameStartAd();
          }
        },
      )
      ..addJavaScriptChannel(
        'BaziNativeAdBridge',
        onMessageReceived: (JavaScriptMessage message) {
          _handleNativeAdSlotMessage(message.message);
        },
      )
      ..addJavaScriptChannel(
        'BaziRewardedAdBridge',
        onMessageReceived: (JavaScriptMessage message) {
          _handleRewardedAdRequest(message.message);
        },
      )
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageFinished: (_) async {
            await _injectGameStartDetector();
            await _injectNativeAdSlotDetector();
            await _injectRewardedVideoBridge();
            if (mounted) setState(() => _loading = false);
          },
        ),
      )
      ..loadFlutterAsset('assets/game.html');
  }

  int _rewardSessionId = 0;
  bool _rewardCallbackReceived = false;

  void _setupAdiveryRewardListener() {
    if (!Platform.isAndroid || _adiveryListenerAttached) return;
    _adiveryListenerAttached = true;
    try {
      AdiveryPlugin.addListener(
        onRewardedClosed: (String placementId, bool isRewarded) async {
          if (_pendingRewardAmount <= 0) return;
          _rewardCallbackReceived = true;
          await _dispatchRewardedResult(isRewarded);
          try {
            AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
          } catch (_) {}
        },
      );
    } catch (_) {}
  }

  Future<void> _dispatchRewardedResult(bool isRewarded) async {
    final amount = _pendingRewardAmount > 0 ? _pendingRewardAmount : 1000;
    final label = _escapeJsString(_pendingRewardLabel);
    final ok = isRewarded ? 'true' : 'false';
    try {
      await _controller.runJavaScript(
        "try{" 
        "if(window.__bhForceRewardGrantFromNative){window.__bhForceRewardGrantFromNative($ok,$amount,'$label');}" 
        "else if(window.baziKhoneRewardedAdResult){window.baziKhoneRewardedAdResult($ok,$amount,'$label');}" 
        "else if($ok && window.bhAddCoins){window.bhAddCoins($amount,'$label');}" 
        "else if(!$ok && window.bhShowToast){window.bhShowToast('برای دریافت سکه باید تبلیغ را کامل ببینی');}" 
        "}catch(e){}",
      );
    } catch (_) {}
    _pendingRewardAmount = 0;
    _pendingRewardLabel = 'پاداش تبلیغ ویدئویی';
  }

  String _escapeJsString(String value) {
    return value
        .replaceAll('\\', '\\\\')
        .replaceAll("'", "\\'")
        .replaceAll('\n', ' ')
        .replaceAll('\r', ' ');
  }

  Future<void> _injectGameStartDetector() async {
    const js = r'''
(function(){
  if (window.__baziKhoneAdiveryBridgeInstalled) return;
  window.__baziKhoneAdiveryBridgeInstalled = true;
  document.addEventListener('click', function(event){
    var target = event.target;
    if (!target) return;
    var gameNode = target.closest ? target.closest('[data-game], .game-card, .game-start, [data-start-game]') : null;
    if (gameNode && window.BaziBridge && window.BaziBridge.postMessage) {
      window.BaziBridge.postMessage('game_start');
    }
  }, true);
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }


  Future<void> _injectNativeAdSlotDetector() async {
    const js = r'''
(function(){
  if (window.__baziKhoneNativeAdiverySlotInstalledV13) return;
  window.__baziKhoneNativeAdiverySlotInstalledV13 = true;

  var lastPayload = '';
  var lastPostAt = 0;
  var scrollLoopUntil = 0;
  var activeSlotId = null;
  var nextSlotId = 1;

  function slotId(slot){
    if (!slot.__bhNativeAdSlotId) slot.__bhNativeAdSlotId = 'slot_' + (nextSlotId++);
    return slot.__bhNativeAdSlotId;
  }

  function visibleArea(rect){
    var vw = window.innerWidth || document.documentElement.clientWidth || 0;
    var vh = window.innerHeight || document.documentElement.clientHeight || 0;
    var x = Math.max(0, Math.min(rect.right, vw) - Math.max(rect.left, 0));
    var y = Math.max(0, Math.min(rect.bottom, vh) - Math.max(rect.top, 0));
    return x * y;
  }

  function post(message, force){
    try{
      var payload = JSON.stringify(message);
      var now = Date.now();
      if (!force && payload === lastPayload && now - lastPostAt < 180) return;
      lastPayload = payload;
      lastPostAt = now;
      if (window.BaziNativeAdBridge && window.BaziNativeAdBridge.postMessage) {
        window.BaziNativeAdBridge.postMessage(payload);
      }
    }catch(e){}
  }

  function isShown(node){
    try{
      if (!node || !node.isConnected) return false;
      var style = window.getComputedStyle(node);
      if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
      var rect = node.getBoundingClientRect();
      if (rect.width < 120 || rect.height < 34) return false;
      return true;
    }catch(e){return false;}
  }

  function hasBlockingOverlay(){
    try{
      var selectors = [
        '.feature-modal.show',
        '.modal.show',
        '.game-confirm-popup.show',
        '.bhp-ticket-modal.show',
        '#videoRewardModal.show',
        '[aria-modal="true"]'
      ];
      for (var i=0;i<selectors.length;i++){
        var nodes = document.querySelectorAll(selectors[i]);
        for (var j=0;j<nodes.length;j++){
          var node = nodes[j];
          var style = window.getComputedStyle(node);
          if (style.display !== 'none' && style.visibility !== 'hidden' && style.opacity !== '0') return true;
        }
      }
    }catch(e){}
    return false;
  }

  function chooseBestSlot(){
    var slots = Array.prototype.slice.call(document.querySelectorAll('.native-adivery-html-slot[data-native-ad-slot="banner"], [data-native-ad-slot="banner"]'));
    var visible = [];
    for (var i=0;i<slots.length;i++){
      var slot = slots[i];
      if (!isShown(slot)) continue;
      var rect = slot.getBoundingClientRect();
      var area = visibleArea(rect);
      if (area < 1600) continue;
      visible.push({slot:slot, rect:rect, area:area, id:slotId(slot)});
    }
    if (!visible.length) return null;

    // Keep the previous visible slot so the banner does not jump between nearby slots.
    if (activeSlotId) {
      for (var k=0;k<visible.length;k++){
        if (visible[k].id === activeSlotId && visible[k].area > 2400) return visible[k];
      }
    }

    visible.sort(function(a,b){ return b.area - a.area; });
    activeSlotId = visible[0].id;
    return visible[0];
  }

  function reportBannerSlot(force){
    try{
      if (hasBlockingOverlay()) {
        activeSlotId = null;
        post({type:'banner_hide'}, force);
        return;
      }
      var best = chooseBestSlot();
      if (!best) {
        activeSlotId = null;
        post({type:'banner_hide'}, force);
        return;
      }

      var rect = best.rect;
      var vv = window.visualViewport || null;
      var offsetLeft = vv ? vv.offsetLeft : 0;
      var offsetTop = vv ? vv.offsetTop : 0;
      var scale = vv && vv.scale ? vv.scale : 1;
      var h = Math.max(50, Math.min(90, rect.height * scale));

      post({
        type:'banner_rect',
        slotId: best.id,
        left: Math.max(0, (rect.left - offsetLeft) * scale),
        top: Math.max(0, (rect.top - offsetTop) * scale),
        width: Math.max(0, rect.width * scale),
        height: h
      }, force);
    }catch(e){
      post({type:'banner_hide'}, force);
    }
  }

  var rafPending = false;
  function scheduleReport(force){
    if (rafPending) return;
    rafPending = true;
    window.requestAnimationFrame(function(){
      rafPending = false;
      reportBannerSlot(!!force);
    });
  }

  function startScrollSync(){
    scrollLoopUntil = Date.now() + 900;
    scheduleReport(true);
  }

  function scrollLoop(){
    if (Date.now() < scrollLoopUntil) {
      reportBannerSlot(true);
      window.requestAnimationFrame(scrollLoop);
    }
  }

  function triggerScrollSync(){
    var wasIdle = Date.now() >= scrollLoopUntil;
    startScrollSync();
    if (wasIdle) window.requestAnimationFrame(scrollLoop);
  }

  window.addEventListener('scroll', triggerScrollSync, true);
  window.addEventListener('touchmove', triggerScrollSync, {capture:true, passive:true});
  window.addEventListener('wheel', triggerScrollSync, {capture:true, passive:true});
  window.addEventListener('resize', function(){ activeSlotId = null; scheduleReport(true); }, true);
  if (window.visualViewport) {
    window.visualViewport.addEventListener('scroll', triggerScrollSync, true);
    window.visualViewport.addEventListener('resize', function(){ activeSlotId = null; scheduleReport(true); }, true);
  }
  document.addEventListener('click', function(){ setTimeout(function(){ scheduleReport(true); }, 80); }, true);
  try{
    var observer = new MutationObserver(function(){ scheduleReport(false); });
    observer.observe(document.documentElement, {subtree:true, attributes:true, childList:true, attributeFilter:['class','style','aria-hidden']});
  }catch(e){}
  setTimeout(function(){ reportBannerSlot(true); }, 180);
  setTimeout(function(){ reportBannerSlot(true); }, 700);
  setInterval(function(){ reportBannerSlot(false); }, 550);
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }


  Future<void> _injectRewardedVideoBridge() async {
    const js = r'''
(function(){
  if (window.__baziKhoneRewardedResultInstalled) return;
  window.__baziKhoneRewardedResultInstalled = true;
  window.baziKhoneRewardedAdResult = window.baziKhoneRewardedAdResult || function(isRewarded, amount, label){
    try{
      var ok = isRewarded === true || isRewarded === 'true' || isRewarded === 1 || isRewarded === '1';
      var finalAmount = Number(amount || 1000);
      var finalLabel = label || 'پاداش تبلیغ ویدئویی';
      var modal = document.getElementById('videoRewardModal');
      if (modal) {
        modal.classList.remove('show');
        modal.setAttribute('aria-hidden', 'true');
      }
      if (ok) {
        if (window.bhAddCoins) window.bhAddCoins(finalAmount, finalLabel);
        else if (window.bhShowToast) window.bhShowToast(finalAmount + ' سکه اضافه شد');
      } else {
        if (window.bhShowToast) window.bhShowToast('برای دریافت سکه باید تبلیغ را کامل ببینی');
      }
    }catch(e){}
  };
})();
''';
    try {
      await _controller.runJavaScript(js);
    } catch (_) {}
  }

  Future<void> _handleRewardedAdRequest(String rawMessage) async {
    var amount = 1000;
    var label = 'پاداش تبلیغ ویدئویی';
    try {
      final decoded = jsonDecode(rawMessage);
      if (decoded is Map<String, dynamic>) {
        final rawAmount = decoded['amount'];
        if (rawAmount is num && rawAmount > 0) amount = rawAmount.toInt();
        final rawLabel = decoded['label'];
        if (rawLabel is String && rawLabel.trim().isNotEmpty) label = rawLabel.trim();
      }
    } catch (_) {}
    await _showRewardedAdFromGame(amount: amount, label: label);
  }

  Future<void> _showRewardedAdFromGame({required int amount, required String label}) async {
    _pendingRewardAmount = amount;
    _pendingRewardLabel = label;

    if (!Platform.isAndroid) {
      try {
        final safeLabel = _escapeJsString(label);
        await _controller.runJavaScript(
          "try{if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(true, $amount, '$safeLabel');}catch(e){}",
        );
      } catch (_) {}
      return;
    }

    final sessionId = ++_rewardSessionId;
    _rewardCallbackReceived = false;

    try {
      await _controller.runJavaScript(
        "try{if(window.bhShowToast)window.bhShowToast('در حال پخش تبلیغ ویدئویی...');}catch(e){}",
      );
      AdiveryPlugin.show(_rewardedPlacementId);
      AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
      Future.delayed(const Duration(seconds: 75), () async {
        if (!mounted) return;
        if (_pendingRewardAmount > 0 && _rewardSessionId == sessionId && !_rewardCallbackReceived) {
          await _dispatchRewardedResult(true);
          try {
            AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
          } catch (_) {}
        }
      });
    } catch (_) {
      try {
        AdiveryPlugin.prepareRewardedAd(_rewardedPlacementId);
      } catch (_) {}
      try {
        await _controller.runJavaScript(
          "try{if(window.baziKhoneRewardedAdResult)window.baziKhoneRewardedAdResult(false, $amount, '${_escapeJsString(label)}');}catch(e){}",
        );
      } catch (_) {}
    }
  }

  void _handleNativeAdSlotMessage(String rawMessage) {
    if (!Platform.isAndroid) return;

    try {
      final decoded = jsonDecode(rawMessage);
      if (decoded is! Map<String, dynamic>) return;
      final type = decoded['type'];

      if (type == 'banner_hide') {
        if (_inlineBannerRect != null && mounted) {
          setState(() => _inlineBannerRect = null);
        }
        return;
      }

      if (type != 'banner_rect') return;

      double readDouble(String key, double fallback) {
        final value = decoded[key];
        if (value is num) return value.toDouble();
        return fallback;
      }

      final nextRect = Rect.fromLTWH(
        readDouble('left', 0),
        readDouble('top', 0),
        readDouble('width', 0),
        readDouble('height', 58),
      );

      if (nextRect.width < 120 || nextRect.height < 40) return;

      final current = _inlineBannerRect;
      final shouldUpdate = current == null ||
          (current.left - nextRect.left).abs() > 0.4 ||
          (current.top - nextRect.top).abs() > 0.4 ||
          (current.width - nextRect.width).abs() > 0.8 ||
          (current.height - nextRect.height).abs() > 0.8;

      if (shouldUpdate && mounted) {
        setState(() => _inlineBannerRect = nextRect);
      }
    } catch (_) {}
  }

  Future<void> _handleGameStartAd() async {
    final prefs = await SharedPreferences.getInstance();
    final nextCount = (prefs.getInt(_gameStartCounterKey) ?? 0) + 1;
    await prefs.setInt(_gameStartCounterKey, nextCount);

    if (nextCount % 5 != 0) return;
    _showInterstitialAd();
  }

  void _showInterstitialAd() {
    if (!Platform.isAndroid) return;
    try {
      AdiveryPlugin.show(_interstitialPlacementId);
      AdiveryPlugin.prepareInterstitialAd(_interstitialPlacementId);
    } catch (_) {}
  }

  Future<bool> _onBackPressed() async {
    if (await _controller.canGoBack()) {
      await _controller.goBack();
      return false;
    }
    return true;
  }

  Future<void> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: const Text('خروج از بازی'),
        content: const Text('می‌خواهی از برنامه خارج شوی؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(false),
            child: const Text('نه'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(context).pop(true),
            child: const Text('خروج'),
          ),
        ],
      ),
    );

    if (shouldExit == true && mounted) {
      Navigator.of(context).maybePop();
    }
  }

  void _openHelp() {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const _HelpPagesSheet(),
    );
  }

  void _openMenu() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (context) {
        return Directionality(
          textDirection: TextDirection.rtl,
          child: Container(
            margin: const EdgeInsets.all(14),
            padding: const EdgeInsets.fromLTRB(16, 18, 16, 16),
            decoration: BoxDecoration(
              color: const Color(0xFF241B52),
              borderRadius: BorderRadius.circular(26),
              boxShadow: const [
                BoxShadow(
                  blurRadius: 24,
                  offset: Offset(0, 10),
                  color: Color(0x55000000),
                ),
              ],
            ),
            child: SafeArea(
              top: false,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'بازی‌خونه',
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 19,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _MenuActionButton(
                    icon: Icons.help_rounded,
                    title: 'راهنمای بازی',
                    subtitle: '۳ صفحه راهنمای سریع',
                    onTap: () {
                      Navigator.of(context).pop();
                      _openHelp();
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.play_circle_fill_rounded,
                    title: 'تبلیغ ویدیویی',
                    subtitle: 'آماده برای جایزه و دریافت امتیاز',
                    onTap: () {
                      Navigator.of(context).pop();
                      _showRewardedAdFromGame(amount: 1000, label: 'پاداش تبلیغ ویدئویی');
                    },
                  ),
                  const SizedBox(height: 10),
                  _MenuActionButton(
                    icon: Icons.exit_to_app_rounded,
                    title: 'خروج از اپ',
                    subtitle: 'بستن برنامه با تأیید کاربر',
                    onTap: () {
                      Navigator.of(context).pop();
                      _confirmExit();
                    },
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      onPopInvoked: (didPop) async {
        if (didPop) return;
        final shouldPop = await _onBackPressed();
        if (shouldPop && mounted) {
          _confirmExit();
        }
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          top: false,
          bottom: false,
          child: Stack(
            children: [
              Positioned.fill(
                child: WebViewWidget(controller: _controller),
              ),
              if (_showChrome && _inlineBannerRect != null)
                _InlineAdiveryBannerOverlay(
                  rect: _inlineBannerRect!,
                  child: _adiveryBannerWidget,
                ),
              if (_loading)
                Container(
                  color: Colors.white,
                  child: const Center(child: CircularProgressIndicator()),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InlineAdiveryBannerOverlay extends StatelessWidget {
  const _InlineAdiveryBannerOverlay({required this.rect, required this.child});

  final Rect rect;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (!Platform.isAndroid) {
      return const SizedBox.shrink();
    }

    final screenSize = MediaQuery.sizeOf(context);
    final safeWidth = rect.width.clamp(160.0, screenSize.width - 16.0).toDouble();
    final maxLeft = (screenSize.width - safeWidth - 8.0).clamp(8.0, screenSize.width).toDouble();
    final safeLeft = rect.left.clamp(8.0, maxLeft).toDouble();
    final safeTop = rect.top.clamp(0.0, screenSize.height - 58.0).toDouble();
    final verticalOffset = ((rect.height - 50).clamp(0.0, 40.0).toDouble()) / 2;

    return Positioned(
      left: safeLeft,
      top: safeTop + verticalOffset,
      width: safeWidth,
      height: 50,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: child,
      ),
    );
  }
}

class _FloatingMenuButton extends StatelessWidget {
  const _FloatingMenuButton({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: const Color(0xDD241B52),
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: const SizedBox(
          width: 44,
          height: 44,
          child: Icon(Icons.menu_rounded, color: Colors.white),
        ),
      ),
    );
  }
}

class _MenuActionButton extends StatelessWidget {
  const _MenuActionButton({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white.withOpacity(0.10),
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Row(
            children: [
              Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: const Color(0xFFFFD166),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Icon(icon, color: const Color(0xFF241B52)),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 15,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: Colors.white.withOpacity(0.74),
                        fontSize: 12,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left_rounded, color: Colors.white),
            ],
          ),
        ),
      ),
    );
  }
}

class _HelpPagesSheet extends StatefulWidget {
  const _HelpPagesSheet();

  @override
  State<_HelpPagesSheet> createState() => _HelpPagesSheetState();
}

class _HelpPagesSheetState extends State<_HelpPagesSheet> {
  final PageController _pageController = PageController();
  int _page = 0;

  static const _pages = [
    _HelpPageData(
      icon: Icons.sports_esports_rounded,
      title: 'شروع بازی',
      text: 'از صفحه اصلی یکی از بازی‌ها را انتخاب کن، مقدار سکه ورود را ببین و بازی را شروع کن. مسیر و ظاهر بازی‌ها همان نسخه اصلی حفظ شده است.',
    ),
    _HelpPageData(
      icon: Icons.monetization_on_rounded,
      title: 'سکه و امتیاز',
      text: 'با بردن بازی‌ها سکه و امتیاز می‌گیری. رتبه، رکورد و جایزه‌ها داخل خود بازی مدیریت می‌شوند و صفحه‌های بازی بدون تغییر اجرا می‌شوند.',
    ),
    _HelpPageData(
      icon: Icons.touch_app_rounded,
      title: 'دکمه‌ها و تبلیغات',
      text: 'از دکمه منو می‌توانی راهنما، تبلیغ ویدیویی و خروج از اپ را باز کنی. تبلیغ تمام‌صفحه هر ۵ بار ورود به بازی فقط یک‌بار نمایش داده می‌شود.',
    ),
  ];

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DraggableScrollableSheet(
        initialChildSize: 0.78,
        minChildSize: 0.45,
        maxChildSize: 0.92,
        builder: (context, scrollController) {
          return Container(
            decoration: const BoxDecoration(
              color: Color(0xFFF8F5FF),
              borderRadius: BorderRadius.vertical(top: Radius.circular(32)),
            ),
            child: Column(
              children: [
                const SizedBox(height: 10),
                Container(
                  width: 48,
                  height: 5,
                  decoration: BoxDecoration(
                    color: const Color(0xFFB9A7E8),
                    borderRadius: BorderRadius.circular(99),
                  ),
                ),
                const SizedBox(height: 16),
                const Text(
                  'راهنمای سریع بازی‌خونه',
                  style: TextStyle(
                    color: Color(0xFF241B52),
                    fontSize: 20,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                Expanded(
                  child: PageView.builder(
                    controller: _pageController,
                    itemCount: _pages.length,
                    onPageChanged: (value) => setState(() => _page = value),
                    itemBuilder: (context, index) {
                      final item = _pages[index];
                      return Padding(
                        padding: const EdgeInsets.all(20),
                        child: Container(
                          padding: const EdgeInsets.all(22),
                          decoration: BoxDecoration(
                            color: Colors.white,
                            borderRadius: BorderRadius.circular(30),
                            boxShadow: const [
                              BoxShadow(
                                blurRadius: 24,
                                offset: Offset(0, 10),
                                color: Color(0x16000000),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Container(
                                width: 96,
                                height: 96,
                                decoration: BoxDecoration(
                                  gradient: const LinearGradient(
                                    colors: [Color(0xFF7C3AED), Color(0xFFFFD166)],
                                  ),
                                  borderRadius: BorderRadius.circular(32),
                                ),
                                child: Icon(item.icon, size: 50, color: Colors.white),
                              ),
                              const SizedBox(height: 24),
                              Text(
                                item.title,
                                style: const TextStyle(
                                  color: Color(0xFF241B52),
                                  fontSize: 22,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 14),
                              Text(
                                item.text,
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                  color: Color(0xFF4C426E),
                                  fontSize: 15,
                                  height: 1.8,
                                  fontWeight: FontWeight.w500,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(
                    _pages.length,
                    (index) => AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.symmetric(horizontal: 4),
                      width: _page == index ? 28 : 9,
                      height: 9,
                      decoration: BoxDecoration(
                        color: _page == index ? const Color(0xFF7C3AED) : const Color(0xFFD8CCF7),
                        borderRadius: BorderRadius.circular(99),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 14),
                Padding(
                  padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
                  child: FilledButton(
                    style: FilledButton.styleFrom(
                      minimumSize: const Size.fromHeight(52),
                      backgroundColor: const Color(0xFF7C3AED),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    onPressed: () {
                      if (_page < _pages.length - 1) {
                        _pageController.nextPage(
                          duration: const Duration(milliseconds: 260),
                          curve: Curves.easeOut,
                        );
                      } else {
                        Navigator.of(context).pop();
                      }
                    },
                    child: Text(_page < _pages.length - 1 ? 'بعدی' : 'متوجه شدم'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}

class _HelpPageData {
  const _HelpPageData({
    required this.icon,
    required this.title,
    required this.text,
  });

  final IconData icon;
  final String title;
  final String text;
}
